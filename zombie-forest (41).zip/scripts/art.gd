@tool
extends RefCounted
# art.gd - THE one place that decides how the game looks.
#
# Other scripts never create materials/meshes/lights/particles themselves, they ask this file:
#     const Art := preload("res://scripts/art.gd")
#     Art.build_gun(...), Art.environment(), Art.make_theme() ...
#
# HOW TO UPGRADE THE GRAPHICS LATER
#   1. Drop real assets in res://assets/ (they are picked up automatically, no code changes):
#        assets/models/zombie.glb | zombie_normal | zombie_runner | zombie_tank   (.glb/.gltf/.tscn, feet at y=0, faces -Z)
#        assets/models/gun_pistol | gun_smg | gun_shotgun | gun_rifle              (barrel points to -Z)
#        assets/textures/ground.png   assets/textures/bark.png   assets/textures/foliage.png
#        assets/fonts/main.ttf  (UI font)
#   2. Or tweak the PALETTE / QUALITY blocks below to restyle everything at once.
#   3. Or replace the body of any build_* function here; callers only depend on the return value.

# ----------------------------------------------------------------------------------------
# QUALITY knobs (lower these if the game runs slowly)
# ----------------------------------------------------------------------------------------
# 0..1: multiplies the brightness of every glowing particle (fire, embers, muzzle flash)
const PARTICLE_BRIGHTNESS := 0.55
# strength of the soft-focus / bloom screen filter (0 = off, ~0.5 = very dreamy)
const SOFT_FILTER := 0.45

const QUALITY := {
	"moon_shadows": true,   # shadows from the moon (trees cast long shadows)
	"glow": true,           # bloom on fire / eyes / muzzle flash
	"grass_spacing": 1.6,   # metres between grass clumps (smaller = denser). One jittered clump per cell, so coverage is even
	"rocks": 70,
	"mushrooms": 45,        # glowing mushrooms
}

# ----------------------------------------------------------------------------------------
# PALETTE
# ----------------------------------------------------------------------------------------
const SKY_TOP := Color(0.004, 0.007, 0.02)
const SKY_HORIZON := Color(0.015, 0.02, 0.04)
const FOG := Color(0.006, 0.008, 0.014)
const AMBIENT := Color(0.2, 0.26, 0.4)
const MOON := Color(0.55, 0.65, 1.0)
const GROUND_DARK := Color(0.07, 0.09, 0.05)
const GROUND_LIGHT := Color(0.2, 0.22, 0.12)
const DIRT := Color(0.16, 0.11, 0.07)
const BARK := Color(0.2, 0.14, 0.1)
const FOLIAGE_A := Color(0.05, 0.16, 0.08)
const FOLIAGE_B := Color(0.1, 0.22, 0.12)
const GRASS_A := Color(0.035, 0.075, 0.03)
const GRASS_B := Color(0.07, 0.12, 0.045)
const STONE := Color(0.2, 0.2, 0.22)
const SHIRTS := [Color(0.22, 0.18, 0.16), Color(0.25, 0.12, 0.1), Color(0.12, 0.17, 0.24),
	Color(0.2, 0.22, 0.15), Color(0.3, 0.28, 0.24)]
const PANTS := [Color(0.1, 0.1, 0.14), Color(0.18, 0.15, 0.1), Color(0.12, 0.16, 0.12)]
const GUN_METAL := Color(0.14, 0.14, 0.17)
const GUN_DARK := Color(0.07, 0.07, 0.08)
const GUN_WOOD := Color(0.28, 0.17, 0.09)

# UI
const UI_PANEL := Color(0.05, 0.05, 0.06, 0.92)
const UI_BORDER := Color(0.55, 0.12, 0.1)
const UI_ACCENT := Color(1.0, 0.75, 0.3)
const UI_HP_LOW := Color(0.85, 0.1, 0.08)
const UI_HP_OK := Color(0.3, 0.75, 0.25)

const MODEL_DIR := "res://assets/models/"
const TEXTURE_DIR := "res://assets/textures/"
const FONT_PATH := "res://assets/fonts/main.ttf"

static var _cache := {}


# ========================================================================================
# small helpers
# ========================================================================================
static func mat(color: Color, rough := 0.9, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	return m


static func glow_mat(color: Color, energy := 3.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	return m


static func box(parent: Node3D, size: Vector3, pos: Vector3, material: Material, rot_deg := Vector3.ZERO) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	m.mesh = bm
	m.position = pos
	m.rotation_degrees = rot_deg
	m.material_override = material
	parent.add_child(m)
	return m


# cylinder / cone, axis along Y (rotate it with rot_deg)
static func cyl(parent: Node3D, radius: float, height: float, pos: Vector3, material: Material, rot_deg := Vector3.ZERO, top_radius := -1.0, segments := 8) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.bottom_radius = radius
	cm.top_radius = radius if top_radius < 0.0 else top_radius
	cm.height = height
	cm.radial_segments = segments
	cm.rings = 1
	m.mesh = cm
	m.position = pos
	m.rotation_degrees = rot_deg
	m.material_override = material
	parent.add_child(m)
	return m


static func ball(parent: Node3D, radius: float, pos: Vector3, material: Material, squash := 1.0) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0 * squash
	sm.radial_segments = 8
	sm.rings = 4
	m.mesh = sm
	m.position = pos
	m.material_override = material
	parent.add_child(m)
	return m


static func multimesh(parent: Node3D, mesh: Mesh, material: Material, xforms: Array[Transform3D], colors: Array[Color] = [], shadows := true) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = not colors.is_empty()
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
		if mm.use_colors:
			mm.set_instance_color(i, colors[i])
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	inst.material_override = material
	if not shadows:
		inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(inst)
	return inst


# Loads res://assets/models/<name>.(tscn|glb|gltf) if it exists, otherwise returns null.
static func model(model_name: String) -> Node3D:
	for ext in ["tscn", "glb", "gltf"]:
		var p: String = MODEL_DIR + model_name + "." + ext
		if ResourceLoader.exists(p):
			var res = load(p)
			if res is PackedScene:
				return res.instantiate() as Node3D
	return null


static func _tex_or(tex_name: String, fallback: Texture2D) -> Texture2D:
	var p := TEXTURE_DIR + tex_name + ".png"
	if ResourceLoader.exists(p):
		return load(p) as Texture2D
	return fallback


static func _noise_tex(freq: float, seed_: int, c1: Color, c2: Color, as_normal := false) -> NoiseTexture2D:
	var n := FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = freq
	n.seed = seed_
	n.fractal_octaves = 4
	var t := NoiseTexture2D.new()
	t.width = 512
	t.height = 512
	t.seamless = true
	t.noise = n
	if as_normal:
		t.as_normal_map = true
		t.bump_strength = 3.0
	else:
		var g := Gradient.new()
		g.set_color(0, c1)
		g.set_color(1, c2)
		t.color_ramp = g
	return t


static func _gradient_tex(cols: Array, offs: Array) -> GradientTexture1D:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array(offs)
	g.colors = PackedColorArray(cols)
	var t := GradientTexture1D.new()
	t.gradient = g
	return t


# soft round blob used by fire, embers, muzzle flash
static func _soft_sprite_mat(tint := Color.WHITE) -> StandardMaterial3D:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.3, 0.7, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0.85), Color(1, 1, 1, 0.5), Color(1, 1, 1, 0.12), Color(1, 1, 1, 0)])
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 64
	t.height = 64
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.billboard_keep_scale = true
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = t
	m.albedo_color = Color(tint.r * PARTICLE_BRIGHTNESS, tint.g * PARTICLE_BRIGHTNESS, tint.b * PARTICLE_BRIGHTNESS, tint.a)
	return m


static func _sprite_quad(size: float, tint := Color.WHITE) -> QuadMesh:
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	q.material = _soft_sprite_mat(tint)
	return q


# ========================================================================================
# world: sky, light, ground, forest
# ========================================================================================
const SKY_SHADER := """
shader_type sky;
uniform vec3 top_color : source_color = vec3(0.004, 0.008, 0.03);
uniform vec3 horizon_color : source_color = vec3(0.025, 0.04, 0.08);
float hash13(vec3 p) {
	p = fract(p * 0.3183099 + 0.1);
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
void sky() {
	vec3 d = normalize(EYEDIR);
	float h = clamp(d.y, 0.0, 1.0);
	vec3 col = mix(horizon_color, top_color, pow(h, 0.45));
	// stars: random cells on the sphere, fade out near the horizon
	vec3 cell = floor(d * 260.0);
	float r = hash13(cell);
	float star = step(0.9955, r) * smoothstep(0.02, 0.35, d.y);
	float tint = hash13(cell + 11.0);
	vec3 star_col = mix(vec3(0.7, 0.8, 1.0), vec3(1.0, 0.9, 0.75), tint);
	col += star_col * star * (0.5 + 1.2 * hash13(cell + 5.0));
	// faint band of haze along the horizon
	col += vec3(0.02, 0.03, 0.05) * pow(1.0 - h, 6.0);
	// moon disc + halo
	if (LIGHT0_ENABLED) {
		float m = dot(d, LIGHT0_DIRECTION);
		float disc = smoothstep(0.9988, 0.9993, m);
		float halo = pow(max(m, 0.0), 220.0) * 0.35 + pow(max(m, 0.0), 24.0) * 0.05;
		col += vec3(0.75, 0.85, 1.0) * disc * 2.2 + vec3(0.4, 0.5, 0.8) * halo;
	}
	COLOR = col;
}
"""


static func environment() -> Environment:
	var sky_shader := Shader.new()
	sky_shader.code = SKY_SHADER
	var sky_mat := ShaderMaterial.new()
	sky_mat.shader = sky_shader
	var sky := Sky.new()
	sky.sky_material = sky_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = AMBIENT
	env.ambient_light_energy = 0.1
	env.fog_enabled = true
	env.fog_light_color = Color(0.012, 0.018, 0.032)   # slightly blue fog: depth instead of a flat black wall
	env.fog_density = 0.06
	env.fog_sky_affect = 0.35                          # lets the stars and moon show through
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 0.95
	env.tonemap_white = 6.0
	env.adjustment_enabled = true
	env.adjustment_contrast = 0.95
	env.adjustment_saturation = 0.85
	if QUALITY.glow:
		env.glow_enabled = true
		env.glow_intensity = 0.5
		env.glow_strength = 0.9
		env.glow_bloom = 0.12
		env.glow_hdr_threshold = 0.9
		env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
		for lvl in [3, 4, 5, 6]:            # wide, soft halos instead of tight bright dots
			env.set_glow_level(lvl, 1.0)
	return env


static func add_moon(parent: Node3D) -> void:
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-55, 30, 0)
	moon.light_color = MOON
	moon.light_energy = 0.1
	if QUALITY.moon_shadows:
		moon.shadow_enabled = true
		moon.directional_shadow_max_distance = 60.0
		moon.shadow_blur = 1.5
		moon.shadow_bias = 0.03
	parent.add_child(moon)


static func ground_material() -> StandardMaterial3D:
	var m := mat(Color.WHITE, 1.0)
	m.albedo_texture = _tex_or("ground", _noise_tex(0.012, 11, GROUND_DARK, GROUND_LIGHT))
	m.normal_enabled = true
	m.normal_texture = _tex_or("ground_n", _noise_tex(0.06, 12, Color.BLACK, Color.WHITE, true))
	m.normal_scale = 1.0
	m.uv1_triplanar = true
	m.uv1_scale = Vector3.ONE * 0.2
	return m


# a patch of bare dirt around the campfire
static func add_clearing(parent: Node3D, radius := 7.0) -> void:
	var dirt_tex := _tex_or("dirt", null)
	var m := mat(Color.WHITE if dirt_tex else DIRT, 1.0)
	m.albedo_texture = dirt_tex if dirt_tex else _noise_tex(0.03, 31, Color(0.6, 0.55, 0.5), Color.WHITE)
	if dirt_tex:
		m.normal_enabled = true
		m.normal_texture = _tex_or("dirt_n", null)
		m.normal_scale = 0.8
	m.uv1_triplanar = true
	m.uv1_scale = Vector3.ONE * 0.35
	var d := cyl(parent, radius, 0.03, Vector3(0, 0.015, 0), m, Vector3.ZERO, -1.0, 32)
	d.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


static func _grass_clump_mesh(w: float, h: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for ang in [0.0, PI / 2.0]:
		var d := Vector3(cos(ang), 0, sin(ang)) * w * 0.5
		var v := [-d, d, d + Vector3.UP * h, -d + Vector3.UP * h]
		var uv := [Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0)]
		for i in [0, 1, 2, 0, 2, 3]:
			st.set_normal(Vector3.UP)
			st.set_uv(uv[i])
			st.add_vertex(v[i])
	return st.commit()


# grass scattered over the arena (trees, rocks, mushrooms are prefab scenes, see world.gd)
# One clump per grid cell, nudged by a random jitter: every spot of ground gets grass (no bald patches,
# no pile-ups like pure random scattering), with far fewer clumps than "just add more".
# The clumps are split into square chunks that hide themselves when far away (the fog hides them anyway).
const GRASS_CHUNK := 16.0          # chunk size in metres
const GRASS_VISIBLE_RANGE := 55.0  # chunks farther than this from the camera are not drawn

static func build_ground_cover(parent: Node3D, arena: float, clear_radius := 5.0, center := Vector2.ZERO) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242

	# two crossed quads textured with assets/textures/grass.png (alpha scissor); falls back to plain cones
	var blade: Mesh
	var gmat := mat(Color.WHITE, 1.0)
	gmat.vertex_color_use_as_albedo = true
	var grass_tex := _tex_or("grass", null)
	if grass_tex:
		blade = _grass_clump_mesh(1.5, 0.8)    # wide clumps, so neighbouring cells overlap and close the gaps
		gmat.albedo_texture = grass_tex
		gmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		gmat.alpha_scissor_threshold = 0.5
		gmat.cull_mode = BaseMaterial3D.CULL_DISABLED
	else:
		var cone := CylinderMesh.new()
		cone.top_radius = 0.0
		cone.bottom_radius = 0.16
		cone.height = 0.55
		cone.radial_segments = 3
		cone.rings = 1
		cone.cap_bottom = false
		blade = cone

	# slow noise makes the grass height vary in soft patches instead of randomly per clump
	var noise := FastNoiseLite.new()
	noise.seed = 77
	noise.frequency = 0.07

	var cell: float = QUALITY.grass_spacing
	var chunks := {}   # Vector2i -> {"x": Array[Transform3D], "c": Array[Color]}
	var n := int(ceil(arena * 2.0 / cell))
	for iz in n:
		for ix in n:
			var p := Vector2(-arena + (ix + rng.randf_range(0.1, 0.9)) * cell, -arena + (iz + rng.randf_range(0.1, 0.9)) * cell)
			if p.distance_to(center) < clear_radius:
				continue
			var patch := noise.get_noise_2d(p.x, p.y) * 0.5 + 0.5          # 0..1
			var sy := lerpf(0.6, 1.4, patch) * rng.randf_range(0.85, 1.15)
			var b := Basis(Vector3.UP, rng.randf() * TAU) * Basis(Vector3.RIGHT, rng.randf_range(-0.2, 0.2)) * Basis.from_scale(Vector3(rng.randf_range(0.85, 1.3), sy, 1.0))
			var key := Vector2i(floori((p.x + arena) / GRASS_CHUNK), floori((p.y + arena) / GRASS_CHUNK))
			if not chunks.has(key):
				chunks[key] = {"x": [] as Array[Transform3D], "c": [] as Array[Color]}
			chunks[key]["x"].append(Transform3D(b, Vector3(p.x, 0.0 if grass_tex else 0.27 * sy, p.y)))
			chunks[key]["c"].append(GRASS_A.lerp(GRASS_B, rng.randf()) * (3.0 if grass_tex else 1.0))
	for key in chunks:
		var inst := multimesh(parent, blade, gmat, chunks[key]["x"], chunks[key]["c"], false)
		inst.visibility_range_end = GRASS_VISIBLE_RANGE
		inst.visibility_range_end_margin = 6.0
		inst.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED


# ========================================================================================
# campfire + atmosphere particles
# ========================================================================================
static func build_campfire(parent: Node3D, light: OmniLight3D) -> void:
	var stone := mat(STONE, 0.95)
	for i in 9:
		var a := TAU * i / 9.0
		var r := ball(parent, 0.22, Vector3(cos(a) * 0.85, 0.07, sin(a) * 0.85), stone, 0.7)
		r.scale = Vector3(1.0 + 0.3 * sin(i * 3.1), 1.0, 1.0 + 0.3 * cos(i * 1.7))
	var logm := mat(Color(0.12, 0.07, 0.04), 1.0)
	for i in 5:
		cyl(parent, 0.07, 1.1, Vector3(0, 0.22, 0), logm, Vector3(68, i * 72.0, 0), 0.06, 6)
	ball(parent, 0.4, Vector3(0, 0.1, 0), glow_mat(Color(1.0, 0.4, 0.08), 1.2), 0.5)  # ember bed

	var flames := flame_particles()
	flames.position = Vector3(0, 0.25, 0)
	parent.add_child(flames)
	var embers := ember_particles()
	embers.position = Vector3(0, 0.4, 0)
	parent.add_child(embers)

	light.position = Vector3(0, 1.2, 0)
	light.light_color = Color(1.0, 0.55, 0.2)
	light.omni_range = 16.0
	light.shadow_enabled = true
	parent.add_child(light)


static func flame_particles() -> GPUParticles3D:
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.22
	pm.direction = Vector3.UP
	pm.spread = 14.0
	pm.initial_velocity_min = 0.7
	pm.initial_velocity_max = 1.5
	pm.gravity = Vector3(0, 1.0, 0)
	pm.scale_min = 0.6
	pm.scale_max = 1.1
	var c := Curve.new()
	c.add_point(Vector2(0, 0.8))
	c.add_point(Vector2(1, 0.0))
	var ct := CurveTexture.new()
	ct.curve = c
	pm.scale_curve = ct
	pm.color_ramp = _gradient_tex(
		[Color(1.0, 0.85, 0.45, 0.6), Color(1.0, 0.45, 0.08, 0.45), Color(0.35, 0.05, 0.0, 0.0)],
		[0.0, 0.45, 1.0])
	var p := GPUParticles3D.new()
	p.amount = 36
	p.lifetime = 0.9
	p.process_material = pm
	p.draw_pass_1 = _sprite_quad(0.6)
	p.visibility_aabb = AABB(Vector3(-2, -1, -2), Vector3(4, 5, 4))
	return p


static func ember_particles() -> GPUParticles3D:
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.3
	pm.direction = Vector3.UP
	pm.spread = 35.0
	pm.initial_velocity_min = 0.8
	pm.initial_velocity_max = 2.2
	pm.gravity = Vector3(0, 0.3, 0)
	pm.scale_min = 0.5
	pm.scale_max = 1.0
	pm.color_ramp = _gradient_tex([Color(1.0, 0.7, 0.2, 0.7), Color(1.0, 0.3, 0.05, 0.0)], [0.0, 1.0])
	var p := GPUParticles3D.new()
	p.amount = 18
	p.lifetime = 2.5
	p.process_material = pm
	p.draw_pass_1 = _sprite_quad(0.06)
	p.visibility_aabb = AABB(Vector3(-4, -1, -4), Vector3(8, 8, 8))
	return p


# round, soft-edged billboard particle (replaces the old square cubes)
static func _round_particle_mat(additive: bool) -> StandardMaterial3D:
	var m := _soft_sprite_mat(Color.WHITE)
	m.albedo_color = Color.WHITE
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD if additive else BaseMaterial3D.BLEND_MODE_MIX
	return m


const SOFT_FILTER_SHADER := """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_linear_mipmap;
uniform float amount = 0.45;
void fragment() {
	vec2 px = SCREEN_PIXEL_SIZE;
	vec3 base = textureLod(screen_tex, SCREEN_UV, 0.0).rgb;
	// cheap wide blur (two rings) = soft, dreamy look
	vec3 blur = vec3(0.0);
	for (int i = 0; i < 8; i++) {
		float a = float(i) * 0.785398;
		vec2 d = vec2(cos(a), sin(a));
		blur += textureLod(screen_tex, SCREEN_UV + d * px * 3.0, 0.0).rgb;
		blur += textureLod(screen_tex, SCREEN_UV + d * px * 6.5, 0.0).rgb;
	}
	blur /= 16.0;
	// bloom: bright areas bleed outward, then get compressed so nothing flashes
	vec3 bright = max(blur - vec3(0.35), vec3(0.0));
	vec3 col = mix(base, blur, amount) + bright * 0.35;
	col = col / (1.0 + max(col - vec3(0.6), vec3(0.0)) * 0.8);   // soften highlights
	COLOR = vec4(col, 1.0);
}
"""


# full-screen soft focus + bloom. Sits under the HUD (layer 0) so UI text stays sharp.
static func build_soft_filter() -> CanvasLayer:
	var layer := CanvasLayer.new()
	layer.name = "SoftFilter"
	layer.layer = 0
	var rect := ColorRect.new()
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = SOFT_FILTER_SHADER
	var sm := ShaderMaterial.new()
	sm.shader = sh
	sm.set_shader_parameter("amount", SOFT_FILTER)
	rect.material = sm
	layer.add_child(rect)
	return layer


# one-shot burst when a bullet hits something (blood on zombies, sparks elsewhere)
static func spawn_impact(parent: Node, pos: Vector3, normal: Vector3, blood: bool) -> void:
	var key := "impact_blood" if blood else "impact_spark"
	if not _cache.has(key):
		_cache[key] = _round_particle_mat(not blood)
	var bm := QuadMesh.new()
	bm.size = Vector2.ONE * (0.1 if blood else 0.06)
	var p := CPUParticles3D.new()
	p.mesh = bm
	p.material_override = _cache[key]
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = 14 if blood else 8
	p.lifetime = 0.5
	p.direction = normal
	p.spread = 50.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 4.5
	p.gravity = Vector3(0, -9.0 if blood else -4.0, 0)
	p.color = Color(0.45, 0.02, 0.02, 0.85) if blood else Color(1.0, 0.8, 0.4, 0.6) * PARTICLE_BRIGHTNESS
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	parent.get_tree().create_timer(1.0).timeout.connect(p.queue_free)


static func _blood_mat() -> StandardMaterial3D:
	if _cache.has("blood_sprite"):
		return _cache["blood_sprite"]
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.55, 0.85, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 1), Color(1, 1, 1, 0.6), Color(1, 1, 1, 0)])
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 64
	t.height = 64
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED   # stays bright red even in the dark forest
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_MIX
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.billboard_keep_scale = true
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = t
	m.no_depth_test = false
	_cache["blood_sprite"] = m
	return m


# Blood for every bullet that hits a zombie: a spray out the exit side, a red mist puff,
# and splats on the ground that fade. `big` = headshot / kill (more of everything).
static func spawn_blood(parent: Node, pos: Vector3, dir: Vector3, ground_y: float, big := false) -> void:
	var d := dir.normalized() if dir.length() > 0.01 else Vector3.UP
	# 1) droplets flying along the shot
	var dm := QuadMesh.new()
	dm.size = Vector2.ONE * 0.13
	var p := CPUParticles3D.new()
	p.mesh = dm
	p.material_override = _blood_mat()
	p.local_coords = true   # follow this node's transform so the spray starts at the hit point
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = 70 if big else 40
	p.lifetime = 1.0
	p.direction = (d + Vector3(0, 0.25, 0)).normalized()
	p.spread = 45.0
	p.initial_velocity_min = 2.5
	p.initial_velocity_max = 9.0 if big else 6.5
	p.gravity = Vector3(0, -13.0, 0)
	p.scale_amount_min = 0.4
	p.scale_amount_max = 1.8
	p.color = Color(0.30, 0.01, 0.01, 1.0)
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	parent.get_tree().create_timer(1.2).timeout.connect(p.queue_free)
	# 2) soft red mist that grows and fades
	var mm := QuadMesh.new()
	mm.size = Vector2.ONE * 0.35
	var m := CPUParticles3D.new()
	m.mesh = mm
	m.material_override = _blood_mat()
	m.local_coords = true
	m.one_shot = true
	m.explosiveness = 1.0
	m.amount = 12 if big else 8
	m.lifetime = 0.6
	m.direction = d
	m.spread = 60.0
	m.initial_velocity_min = 0.3
	m.initial_velocity_max = 1.2
	m.gravity = Vector3(0, -1.0, 0)
	m.scale_amount_min = 0.6
	m.scale_amount_max = 1.3
	var g := Gradient.new()
	g.set_color(0, Color(0.30, 0.01, 0.01, 0.6))
	g.set_color(1, Color(0.15, 0.0, 0.0, 0.0))
	m.color_ramp = g
	parent.add_child(m)
	m.global_position = pos
	m.emitting = true
	parent.get_tree().create_timer(0.8).timeout.connect(m.queue_free)
	# 3) splats on the ground, thrown in the shot direction, fading out
	var flat := Vector3(d.x, 0.0, d.z)
	flat = flat.normalized() if flat.length() > 0.01 else Vector3.FORWARD
	var count := 4 if big else 2
	for i in count:
		var q := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2.ONE * randf_range(0.2, 0.55 if big else 0.4)
		q.mesh = qm
		var sm := _soft_sprite_mat(Color.WHITE)
		sm.blend_mode = BaseMaterial3D.BLEND_MODE_MIX
		sm.billboard_mode = BaseMaterial3D.BILLBOARD_DISABLED
		sm.albedo_color = Color(0.18, 0.01, 0.01, 0.9)
		sm.cull_mode = BaseMaterial3D.CULL_DISABLED
		q.material_override = sm
		q.rotation_degrees = Vector3(-90, 0, 0)
		parent.add_child(q)
		var off := flat * randf_range(0.3, 2.2) + Vector3(randf_range(-0.3, 0.3), 0, randf_range(-0.3, 0.3))
		q.global_position = Vector3(pos.x + off.x, ground_y + 0.03 + i * 0.002, pos.z + off.z)
		q.rotate_y(randf() * TAU)
		var t := q.create_tween()
		t.tween_interval(6.0)
		t.tween_property(sm, "albedo_color:a", 0.0, 3.0)
		t.tween_callback(q.queue_free)


# ========================================================================================
# weapons (first-person). Barrel points to -Z, centered on the node origin.
# `size` is Game.WEAPONS[w].size (overall length is size.z).
# ========================================================================================
static func build_gun(w: String, size: Vector3) -> Node3D:
	var custom := model("gun_" + w)
	if custom != null:
		return custom
	var g := Node3D.new()
	var metal := mat(GUN_METAL, 0.35, 0.8)
	var dark := mat(GUN_DARK, 0.6, 0.3)
	var wood := mat(GUN_WOOD, 0.7)
	var L := size.z
	match w:
		"pistol":
			_build_pistol(g)
		"smg":
			box(g, Vector3(size.x, size.y * 0.8, L * 0.55), Vector3(0, 0.0, L * 0.1), metal)                # receiver
			cyl(g, 0.02, L * 0.3, Vector3(0, 0.01, -L * 0.37), dark, Vector3(90, 0, 0))                     # barrel
			box(g, Vector3(0.04, 0.2, 0.06), Vector3(0, -0.14, L * 0.02), dark).name = "Mag"  # magazine
			box(g, Vector3(0.05, 0.12, 0.06), Vector3(0, -0.1, L * 0.28), dark, Vector3(12, 0, 0))          # grip
			box(g, Vector3(0.03, 0.05, L * 0.18), Vector3(0, 0.0, L * 0.45), metal)                         # stock
			box(g, Vector3(0.02, 0.03, 0.03), Vector3(0, size.y * 0.5, -L * 0.2), dark)                     # sight
		"shotgun":
			cyl(g, 0.028, L * 0.62, Vector3(0, 0.02, -L * 0.2), metal, Vector3(90, 0, 0))                   # barrel
			cyl(g, 0.022, L * 0.5, Vector3(0, -0.03, -L * 0.15), dark, Vector3(90, 0, 0))                   # tube magazine
			box(g, Vector3(0.07, 0.06, L * 0.2), Vector3(0, -0.04, -L * 0.2), wood).name = "Pump"  # pump
			box(g, Vector3(size.x * 0.75, size.y * 0.9, L * 0.22), Vector3(0, 0.0, L * 0.14), metal)       # receiver
			box(g, Vector3(0.06, 0.1, L * 0.24), Vector3(0, -0.02, L * 0.38), wood, Vector3(-6, 0, 0))     # stock
		"rifle":
			cyl(g, 0.016, L * 0.4, Vector3(0, 0.02, -L * 0.3), metal, Vector3(90, 0, 0))                    # barrel
			box(g, Vector3(0.06, 0.07, L * 0.3), Vector3(0, 0.0, -L * 0.22), wood)                          # handguard
			box(g, Vector3(size.x * 0.85, size.y * 0.8, L * 0.34), Vector3(0, 0.01, L * 0.05), metal)      # receiver
			cyl(g, 0.025, 0.22, Vector3(0, 0.1, -0.02), dark, Vector3(90, 0, 0))                            # scope
			box(g, Vector3(0.045, 0.17, 0.07), Vector3(0, -0.13, L * 0.03), dark, Vector3(8, 0, 0)).name = "Mag"  # magazine
			box(g, Vector3(0.06, 0.12, L * 0.24), Vector3(0, -0.02, L * 0.4), wood)                         # stock
		"bat":
			# aluminium bat, built along -z with the knob at the origin, then tipped up to be held
			var tape := mat(Color(0.05, 0.05, 0.055), 0.95)
			var alu := mat(Color(0.68, 0.66, 0.62), 0.45, 0.75)    # worn silver
			var scuff := mat(Color(0.32, 0.30, 0.28), 0.8, 0.3)
			var rubber := mat(Color(0.04, 0.04, 0.045), 0.9)
			# (in cyl(), the bottom radius is the end towards -z, the top radius towards +z)
			cyl(g, 0.017, 0.035, Vector3(0, 0, 0.0), rubber, Vector3(90, 0, 0), 0.027, 10)            # flared knob
			cyl(g, 0.0165, 0.30, Vector3(0, 0, -0.19), tape, Vector3(90, 0, 0), 0.0165, 10)           # taped handle
			cyl(g, 0.017, 0.015, Vector3(0, 0, -0.35), rubber, Vector3(90, 0, 0), 0.0185, 10)         # tape end ring
			cyl(g, 0.037, 0.30, Vector3(0, 0, -0.50), alu, Vector3(90, 0, 0), 0.016, 12)              # long taper
			cyl(g, 0.039, 0.42, Vector3(0, 0, -0.86), alu, Vector3(90, 0, 0), 0.037, 12)              # barrel
			cyl(g, 0.026, 0.035, Vector3(0, 0, -1.085), alu, Vector3(90, 0, 0), 0.039, 12)            # rounded end
			# scuffs and dings on the barrel
			box(g, Vector3(0.012, 0.004, 0.05), Vector3(0.0, 0.039, -0.95), scuff, Vector3(0, 20, 0))
			box(g, Vector3(0.02, 0.004, 0.03), Vector3(0.025, 0.03, -0.80), scuff, Vector3(0, -30, 0))
			box(g, Vector3(0.008, 0.004, 0.08), Vector3(-0.03, 0.025, -0.72), scuff, Vector3(0, 10, 0))
			box(g, Vector3(0.025, 0.004, 0.02), Vector3(-0.01, 0.038, -0.62), scuff, Vector3(0, 40, 0))
			cyl(g, 0.0395, 0.006, Vector3(0, 0, -0.665), scuff, Vector3(90, 0, 0), 0.0395, 12)         # worn ring
			g.rotation_degrees = Vector3(55, 0, -18)
		_:
			box(g, size, Vector3.ZERO, metal)
	_no_shadows(g)
	return g


# first-person guns never cast shadows (also covers meshes nested inside parts like the pistol slide)
static func _no_shadows(n: Node) -> void:
	for c in n.get_children():
		if c is GeometryInstance3D:
			c.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_no_shadows(c)


# Semi-auto pistol: steel slide with serrations, sights and ejection port, polymer frame with
# trigger guard and trigger, ridged raked grip, separate magazine.
# Barrel points to -Z. Nodes named "Slide" and "Mag" are animated by player.gd (slide kick, reload).
static func _build_pistol(g: Node3D) -> void:
	var steel := mat(Color(0.13, 0.13, 0.15), 0.28, 0.9)
	var poly := mat(Color(0.055, 0.055, 0.06), 0.8)
	var ridge := mat(Color(0.1, 0.1, 0.105), 0.95)
	var silver := mat(Color(0.5, 0.5, 0.55), 0.3, 0.9)
	var black := mat(Color(0.015, 0.015, 0.02), 0.7)
	var dot := glow_mat(Color(0.35, 1.0, 0.45), 1.2)

	# ---- frame, dust cover, trigger guard, trigger ----
	box(g, Vector3(0.05, 0.022, 0.24), Vector3(0, 0.008, 0.0), poly)
	box(g, Vector3(0.05, 0.022, 0.05), Vector3(0, 0.008, -0.125), poly)
	box(g, Vector3(0.008, 0.026, 0.007), Vector3(0, -0.014, -0.012), poly, Vector3(18, 0, 0))   # guard front
	box(g, Vector3(0.008, 0.006, 0.058), Vector3(0, -0.028, 0.014), poly)                       # guard bottom
	box(g, Vector3(0.007, 0.02, 0.006), Vector3(0, -0.013, 0.012), silver, Vector3(-15, 0, 0))  # trigger
	box(g, Vector3(0.004, 0.008, 0.022), Vector3(-0.0265, 0.013, 0.02), silver)                 # slide stop (left)
	box(g, Vector3(0.004, 0.008, 0.008), Vector3(0.0245, -0.004, 0.034), silver)                # mag release (right)

	# ---- slide (moves back as one piece) ----
	var slide := Node3D.new()
	slide.name = "Slide"
	g.add_child(slide)
	box(slide, Vector3(0.056, 0.036, 0.27), Vector3(0, 0.038, -0.015), steel)
	box(slide, Vector3(0.03, 0.006, 0.26), Vector3(0, 0.059, -0.015), steel)                    # raised top rib
	for i in 5:
		box(slide, Vector3(0.0585, 0.03, 0.0035), Vector3(0, 0.038, 0.07 + i * 0.011), black)   # rear serrations
	for i in 3:
		box(slide, Vector3(0.0585, 0.03, 0.0035), Vector3(0, 0.038, -0.125 - i * 0.011), black) # front serrations
	box(slide, Vector3(0.004, 0.014, 0.045), Vector3(0.028, 0.047, -0.01), black)               # ejection port
	cyl(slide, 0.0115, 0.02, Vector3(0, 0.036, -0.158), black, Vector3(90, 0, 0))               # muzzle
	box(slide, Vector3(0.008, 0.011, 0.012), Vector3(0, 0.0675, -0.138), steel)                 # front sight
	box(slide, Vector3(0.004, 0.004, 0.002), Vector3(0, 0.0675, -0.1445), dot)
	for sx in [-1.0, 1.0]:
		box(slide, Vector3(0.009, 0.01, 0.01), Vector3(sx * 0.009, 0.066, 0.108), steel)       # rear sight
		box(slide, Vector3(0.003, 0.003, 0.002), Vector3(sx * 0.009, 0.066, 0.1025), dot)

	# ---- grip (raked back) ----
	var grip := Node3D.new()
	grip.position = Vector3(0, -0.038, 0.075)
	grip.rotation_degrees = Vector3(-14, 0, 0)
	g.add_child(grip)
	box(grip, Vector3(0.038, 0.10, 0.058), Vector3.ZERO, poly)
	box(grip, Vector3(0.034, 0.012, 0.03), Vector3(0, 0.05, 0.035), poly)                       # beavertail
	box(grip, Vector3(0.026, 0.09, 0.006), Vector3(0, -0.005, 0.032), ridge)                    # backstrap
	box(grip, Vector3(0.044, 0.008, 0.066), Vector3(0, -0.052, 0.0), poly)                      # magwell flare
	for i in 6:
		box(grip, Vector3(0.0405, 0.0025, 0.05), Vector3(0, -0.035 + i * 0.014, 0.002), ridge)  # side ridges

	# ---- magazine (drops out on reload) ----
	var mag := Node3D.new()
	mag.name = "Mag"
	mag.position = Vector3(0, -0.0865, 0.087)
	mag.rotation_degrees = Vector3(-14, 0, 0)
	g.add_child(mag)
	box(mag, Vector3(0.032, 0.085, 0.052), Vector3(0, 0.04, 0), steel)
	box(mag, Vector3(0.046, 0.01, 0.066), Vector3(0, -0.006, 0), silver)                        # base plate


# barrel tip of each weapon in gun-local space, so the flash and light start exactly at the muzzle
static func muzzle_tip(w: String, size: Vector3) -> Vector3:
	match w:
		"pistol":
			return Vector3(0, 0.036, -0.168)
		"smg":
			return Vector3(0, 0.01, -size.z * 0.52)
		"shotgun":
			return Vector3(0, 0.02, -size.z * 0.51)
		"rifle":
			return Vector3(0, 0.02, -size.z * 0.5)
	return Vector3(0, 0, -size.z * 0.5)


# one flat triangle: wide at the origin, fading to nothing at the tip
static func _flash_spike(st: SurfaceTool, origin: Vector3, dir: Vector3, side: Vector3, length: float, width: float, c_base: Color, c_tip: Color) -> void:
	st.set_color(c_base)
	st.add_vertex(origin + side * width)
	st.set_color(c_base)
	st.add_vertex(origin - side * width)
	st.set_color(c_tip)
	st.add_vertex(origin + dir * length)


# one colour layer of the flash: a big forward triangle (crossed in 3 planes so it reads from any angle),
# two flanking spikes beside each, and a ring of uneven spikes facing the camera. k scales the layer.
static func _flash_layer(st: SurfaceTool, k: float, c_base: Color) -> void:
	var c_tip := Color(c_base.r, c_base.g, c_base.b, 0.0)
	var lens: Array[float] = [0.11, 0.05, 0.095, 0.045, 0.12, 0.06, 0.09]
	for i in lens.size():
		var ang := TAU * float(i) / float(lens.size()) + 0.35 * sin(float(i) * 2.7)
		var rdir := Vector3(cos(ang), sin(ang), 0.0)
		var rside := Vector3(-rdir.y, rdir.x, 0.0)
		_flash_spike(st, Vector3(0, 0, 0.005), rdir, rside, lens[i] * k, 0.02 * k, c_base, c_tip)
	var fwd := Vector3(0, 0, -1)
	for j in 3:
		var phi := PI * float(j) / 3.0
		var side := Vector3(cos(phi), sin(phi), 0.0)
		_flash_spike(st, Vector3.ZERO, fwd, side, 0.22 * k, 0.035 * k, c_base, c_tip)
		for sgn in [-1.0, 1.0]:
			var fdir: Vector3 = (fwd * cos(0.5) + side * float(sgn) * sin(0.5)).normalized()
			_flash_spike(st, Vector3.ZERO, fdir, side, 0.12 * k, 0.02 * k, c_base, c_tip)


# muzzle flash: orange triangle with spikes and a hot white core. Its origin is the barrel tip and it
# points to -Z. Hidden by default; player.gd shows it for a few frames and rolls it around Z.
static func muzzle_flash() -> MeshInstance3D:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_flash_layer(st, 1.0, Color(1.0, 0.5, 0.12, 0.9))
	_flash_layer(st, 0.62, Color(1.0, 0.85, 0.4, 0.95))
	_flash_layer(st, 0.3, Color(1.0, 1.0, 0.9, 1.0))
	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fm.cull_mode = BaseMaterial3D.CULL_DISABLED
	fm.vertex_color_use_as_albedo = true
	var m := MeshInstance3D.new()
	m.mesh = st.commit()
	m.material_override = fm
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	m.visible = false
	# small soft glow right at the barrel opening
	var core := MeshInstance3D.new()
	core.mesh = _sprite_quad(0.14, Color(1.0, 0.9, 0.6))
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	m.add_child(core)
	return m


# ========================================================================================
# loot + floating text
# ========================================================================================
static func loot_color(type: String) -> Color:
	return Color(1.0, 0.8, 0.2) if type == "money" else Color(0.55, 1.0, 0.45)


static func build_loot(type: String) -> Node3D:
	var custom := model("loot_" + type)
	if custom != null:
		return custom
	var g := Node3D.new()
	if type == "money":
		var gold := mat(Color(1.0, 0.78, 0.15), 0.25, 0.9)
		gold.emission_enabled = true
		gold.emission = Color(1.0, 0.65, 0.1)
		gold.emission_energy_multiplier = 0.5
		cyl(g, 0.16, 0.04, Vector3(0, 0.0, 0), gold, Vector3(90, 0, 0), -1.0, 14)             # big coin
		cyl(g, 0.11, 0.045, Vector3(0, 0.0, 0), mat(Color(0.8, 0.55, 0.08), 0.3, 0.9), Vector3(90, 0, 0), -1.0, 14)  # inner ring
		cyl(g, 0.1, 0.035, Vector3(0.2, -0.1, 0.03), gold, Vector3(90, 20, 0), -1.0, 12)      # small coins
		cyl(g, 0.1, 0.035, Vector3(-0.18, -0.12, -0.04), gold, Vector3(90, -15, 0), -1.0, 12)
	else:
		var olive := mat(Color(0.25, 0.3, 0.14), 0.8)
		var strap := mat(Color(0.12, 0.14, 0.07), 0.8)
		var brass := mat(Color(0.9, 0.7, 0.25), 0.3, 0.9)
		brass.emission_enabled = true
		brass.emission = Color(0.9, 0.6, 0.1)
		brass.emission_energy_multiplier = 0.3
		box(g, Vector3(0.34, 0.18, 0.22), Vector3.ZERO, olive)
		box(g, Vector3(0.06, 0.19, 0.23), Vector3(0.0, 0.0, 0.0), strap)
		box(g, Vector3(0.36, 0.03, 0.04), Vector3(0, 0.1, 0.08), strap)
		for i in 3:
			var x := -0.09 + i * 0.09
			cyl(g, 0.022, 0.12, Vector3(x, 0.15, 0.0), brass, Vector3(0, 0, 0), 0.016, 8)    # bullets standing on top
	for c in g.get_children():
		if c is GeometryInstance3D:
			c.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return g


# small burst of colored cubes (loot landing / pickup sparkle)
static func burst(parent: Node, pos: Vector3, color: Color, amount := 10, speed := 2.5) -> void:
	if not _cache.has("burst"):
		_cache["burst"] = _round_particle_mat(true)
	var bm := QuadMesh.new()
	bm.size = Vector2.ONE * 0.07
	var p := CPUParticles3D.new()
	p.mesh = bm
	p.material_override = _cache["burst"]
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = amount
	p.lifetime = 0.55
	p.direction = Vector3.UP
	p.spread = 70.0
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -7.0, 0)
	p.color = Color(color.r * PARTICLE_BRIGHTNESS, color.g * PARTICLE_BRIGHTNESS, color.b * PARTICLE_BRIGHTNESS, 0.7)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.4
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	parent.get_tree().create_timer(1.0).timeout.connect(p.queue_free)


# floating billboard text that pops up, drifts upward and fades ("+$10", "HEADSHOT")
static func popup_text(parent: Node, pos: Vector3, text: String, color: Color, text_scale := 1.0) -> void:
	var l := Label3D.new()
	l.text = text
	l.modulate = color
	l.outline_modulate = Color(0, 0, 0, 0.9)
	l.outline_size = 14
	l.font_size = 40
	l.pixel_size = 0.0045 * text_scale
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.shaded = false
	l.double_sided = true
	parent.add_child(l)
	l.global_position = pos
	l.scale = Vector3.ONE * 0.3
	var t := l.create_tween()
	t.set_parallel(true)
	t.tween_property(l, "scale", Vector3.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(l, "position:y", pos.y + 0.9, 1.0).set_ease(Tween.EASE_OUT)
	t.tween_property(l, "modulate:a", 0.0, 0.45).set_delay(0.55)
	t.chain().tween_callback(l.queue_free)


# ========================================================================================
# UI
# ========================================================================================
static func _panel(bg: Color, border: Color, radius := 6, border_w := 2, pad := 8) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(pad)
	return sb


static func make_theme() -> Theme:
	var t := Theme.new()
	if ResourceLoader.exists(FONT_PATH):
		t.default_font = load(FONT_PATH)
	t.set_stylebox("panel", "PanelContainer", _panel(UI_PANEL, UI_BORDER, 10, 2, 4))
	t.set_stylebox("normal", "Button", _panel(Color(0.16, 0.14, 0.13, 0.95), Color(0.35, 0.1, 0.08), 5, 1, 8))
	t.set_stylebox("hover", "Button", _panel(Color(0.26, 0.18, 0.12, 0.95), UI_ACCENT, 5, 1, 8))
	t.set_stylebox("pressed", "Button", _panel(Color(0.1, 0.08, 0.07, 0.95), UI_ACCENT, 5, 1, 8))
	t.set_stylebox("disabled", "Button", _panel(Color(0.09, 0.09, 0.09, 0.7), Color(0.2, 0.2, 0.2), 5, 1, 8))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color(0.92, 0.88, 0.8))
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_disabled_color", "Button", Color(0.45, 0.45, 0.45))
	t.set_stylebox("background", "ProgressBar", _panel(Color(0.05, 0.02, 0.02, 0.8), Color(0.0, 0.0, 0.0, 0.9), 4, 2, 0))
	t.set_stylebox("fill", "ProgressBar", _panel(UI_HP_OK, UI_HP_OK, 3, 0, 0))
	return t


static func health_color(ratio: float) -> Color:
	return UI_HP_LOW.lerp(UI_HP_OK, clampf(ratio, 0.0, 1.0))


# radial vignette: transparent in the middle, `color` at the edges
static func vignette(color: Color, inner := 0.5) -> TextureRect:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([inner, 1.0])
	g.colors = PackedColorArray([Color(color, 0.0), color])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 256
	gt.height = 256
	var r := TextureRect.new()
	r.texture = gt
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_SCALE
	r.anchor_right = 1.0
	r.anchor_bottom = 1.0
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r


# four ticks + dot, each with a dark outline so it reads on any background
static func crosshair() -> Control:
	var c := Control.new()
	c.anchor_left = 0.5
	c.anchor_right = 0.5
	c.anchor_top = 0.5
	c.anchor_bottom = 0.5
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rects := [Rect2(-1, -12, 2, 7), Rect2(-1, 5, 2, 7), Rect2(-12, -1, 7, 2), Rect2(5, -1, 7, 2), Rect2(-1, -1, 2, 2)]
	for pass_i in 2:
		for r in rects:
			var cr := ColorRect.new()
			cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			if pass_i == 0:
				cr.color = Color(0, 0, 0, 0.7)
				cr.position = r.position - Vector2.ONE
				cr.size = r.size + Vector2.ONE * 2.0
			else:
				cr.color = Color(1, 1, 1, 0.9)
				cr.position = r.position
				cr.size = r.size
			c.add_child(cr)
	return c
