extends Node
# Global game state (autoload "Game"): money, weapons, upgrades, health, wave.

signal changed          # anything in the state changed (HUD refreshes)
signal hurt             # player took damage
signal died             # player died
signal message(text)    # big banner text

const ORDER := ["pistol", "smg", "shotgun", "rifle", "bat"]

# interval = seconds between shots, spread = random aim error, price 0 = owned from the start
const WEAPONS := {
	"pistol": {"name": "Pistol", "damage": 25.0, "interval": 0.32, "mag": 12, "reload": 1.2,
		"pellets": 1, "spread": 0.004, "auto": false, "price": 0, "size": Vector3(0.07, 0.12, 0.32)},
	"smg": {"name": "SMG", "damage": 13.0, "interval": 0.085, "mag": 30, "reload": 1.6,
		"pellets": 1, "spread": 0.02, "auto": true, "price": 350, "size": Vector3(0.08, 0.12, 0.5)},
	"shotgun": {"name": "Shotgun", "damage": 11.0, "interval": 0.85, "mag": 6, "reload": 2.2,
		"pellets": 8, "spread": 0.07, "auto": false, "price": 600, "size": Vector3(0.1, 0.12, 0.65)},
	"rifle": {"name": "Rifle", "damage": 48.0, "interval": 0.17, "mag": 25, "reload": 1.9,
		"pellets": 1, "spread": 0.006, "auto": true, "price": 1000, "size": Vector3(0.08, 0.13, 0.8)},
	# melee: no ammo, hits what is in front of you, huge knockback, headshots always kill
	"bat": {"name": "Metal Bat", "damage": 40.0, "interval": 0.6, "mag": 1, "reload": 0.0,
		"pellets": 0, "spread": 0.0, "auto": false, "price": 0, "melee": true, "size": Vector3(0.06, 0.06, 0.3)},
}

const UPGRADES := {"damage": "Damage", "rate": "Fire rate", "mag": "Magazine", "reload": "Reload"}
const MAX_LEVEL := 5

var money := 0
var kills := 0
var wave := 0
var health := 100.0
var max_health := 100.0
var dead := false
var reloading := false
var current := "pistol"
var owned := {}
var levels := {}
var sensitivity := 1.0   # mouse sensitivity multiplier (set in the Esc menu, saved to disk)
var ammo := {}      # rounds in the magazine
var reserve := {}   # spare rounds (filled by ammo drops)


const SETTINGS_PATH := "user://settings.cfg"


func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		sensitivity = clampf(float(cfg.get_value("controls", "sensitivity", 1.0)), 0.1, 5.0)
	reset()


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("controls", "sensitivity", sensitivity)
	cfg.save(SETTINGS_PATH)


func reset() -> void:
	money = 100
	kills = 0
	wave = 0
	max_health = 100.0
	health = max_health
	dead = false
	reloading = false
	current = "pistol"
	owned = {"pistol": true, "bat": true}
	levels = {}
	ammo = {}
	reserve = {}
	for w in ORDER:
		levels[w] = {"damage": 0, "rate": 0, "mag": 0, "reload": 0}
		ammo[w] = mag(w)
		reserve[w] = 0
	reserve["pistol"] = 36
	changed.emit()


# ---- weapon stats (base stats + upgrade levels) ----
func damage(w: String) -> float:
	return WEAPONS[w].damage * (1.0 + 0.25 * levels[w].damage)

func interval(w: String) -> float:
	return WEAPONS[w].interval * pow(0.9, levels[w].rate)

func mag(w: String) -> int:
	return int(round(WEAPONS[w].mag * (1.0 + 0.25 * levels[w].mag)))

func reload_time(w: String) -> float:
	return WEAPONS[w].reload * pow(0.88, levels[w].reload)


# ---- shop ----
func upgrade_cost(w: String, key: String) -> int:
	return int((100.0 + WEAPONS[w].price * 0.15) * (levels[w][key] + 1))

func buy_upgrade(w: String, key: String) -> void:
	if levels[w][key] >= MAX_LEVEL:
		return
	var cost := upgrade_cost(w, key)
	if money < cost:
		return
	money -= cost
	levels[w][key] += 1
	changed.emit()

func buy_weapon(w: String) -> void:
	var price: int = WEAPONS[w].price
	if owned.has(w) or money < price:
		return
	money -= price
	owned[w] = true
	ammo[w] = mag(w)
	reserve[w] = mag(w)
	current = w
	reloading = false
	changed.emit()

func equip(w: String) -> void:
	if not owned.has(w) or current == w:
		return
	current = w
	reloading = false
	changed.emit()

func buy_medkit() -> void:
	if money < 100 or health >= max_health:
		return
	money -= 100
	heal(50.0)


# ---- player / progress ----
func add_kill() -> void:
	kills += 1   # money now comes from loot drops the player has to pick up
	changed.emit()

func add_money(amount: int) -> void:
	money += amount
	changed.emit()

func heal(amount: float) -> void:
	health = minf(max_health, health + amount)
	changed.emit()

func hurt_player(amount: float) -> void:
	if dead:
		return
	health -= amount
	hurt.emit()
	if health <= 0.0:
		health = 0.0
		dead = true
		died.emit()
	changed.emit()


# ---- loot / spare ammo ----
func reserve_cap(w: String) -> int:
	return mag(w) * 6

# which weapon an ammo drop is for: usually the one in your hands, else any owned gun
func is_melee(w: String) -> bool:
	return WEAPONS[w].get("melee", false)

func pick_ammo_weapon() -> String:
	if not is_melee(current) and randf() < 0.55:
		return current
	var list := []
	for k in owned.keys():
		if not is_melee(k):
			list.append(k)
	return list[randi() % list.size()]

func ammo_drop_amount(w: String) -> int:
	return maxi(3, int(round(mag(w) * randf_range(0.4, 0.8))))

# more likely to drop ammo when you are running dry
func ammo_drop_chance() -> float:
	if is_melee(current):
		return 0.4
	if ammo[current] + reserve[current] <= 0:
		return 1.0
	if reserve[current] < mag(current):
		return 0.6
	return 0.4

# returns how many rounds were actually added (0 if that gun is full)
func add_ammo(w: String, amount: int) -> int:
	var room: int = reserve_cap(w) - reserve[w]
	var added: int = clampi(amount, 0, maxi(room, 0))
	reserve[w] += added
	changed.emit()
	return added
