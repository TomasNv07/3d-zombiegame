@tool
extends RefCounted
# Builds the whole map (environment, moon, ground, trees, grass, rocks, campfire)
# under one "World" node.
#   * scenes/map.tscn is the SAVED result of this. Open that scene in the editor to move trees etc.
#   * scripts/bake_world.gd re-creates map.tscn from scratch (a fresh random forest, hand edits are lost).
#   * main.gd only calls build() at runtime if main.tscn has no "World" node (safety net).

const Art := preload("res://scripts/art.gd")
# prefab scenes: every instance shares the same meshes, materials and textures
const TREE := preload("res://scenes/tree.tscn")
const DEAD_TREE := preload("res://scenes/dead_tree.tscn")
const ROCK := preload("res://scenes/rock.tscn")
const MUSHROOM := preload("res://scenes/mushroom.tscn")
const CABIN := preload("res://scenes/cabin.tscn")
const GROUND_COVER := preload("res://scripts/ground_cover.gd")
const TREE_MIN_DIST := 5.5   # min distance between tree centers (m)


static func build(parent: Node3D, arena := 58.0, tree_count := 260) -> Node3D:
	var world := Node3D.new()
	world.name = "World"
	parent.add_child(world)

	var we := WorldEnvironment.new()
	we.name = "WorldEnvironment"
	we.environment = Art.environment()
	world.add_child(we)
	_named(world, "Moon", func(): Art.add_moon(world))

	_ground(world, arena)
	_forest(world, arena, tree_count)

	var camp := Node3D.new()
	camp.name = "Campfire"
	world.add_child(camp)
	_named(camp, "Clearing", func(): Art.add_clearing(camp))   # dirt patch moves with the fire
	var first := camp.get_child_count()
	var light := OmniLight3D.new()
	light.name = "FireLight"
	Art.build_campfire(camp, light)
	_name_campfire_parts(camp, first)

	var cabin: Node3D = CABIN.instantiate()   # red cabin just west of the dirt clearing
	cabin.name = "Cabin"
	cabin.position = Vector3(-10, 0, 1)
	world.add_child(cabin)

	_tidy(world)
	return world


# the campfire pieces come out of Art.build_campfire in a fixed order: 9 stones, 5 logs, embers, 2 particle nodes, light
static func _name_campfire_parts(camp: Node3D, first: int) -> void:
	var names: Array[String] = []
	for i in 9: names.append("Stone%d" % i)
	for i in 5: names.append("Log%d" % i)
	names.append_array(["EmberBed", "Flames", "Embers"])
	for i in names.size():
		if first + i < camp.get_child_count():
			camp.get_child(first + i).name = names[i]


# Builds a fresh map and saves it as a scene (used by scripts/bake_world.gd). Returns an Error code.
static func save_map(path := "res://scenes/map.tscn", arena := 58.0, tree_count := 260) -> int:
	var holder := Node3D.new()
	var world := build(holder, arena, tree_count)
	holder.remove_child(world)
	holder.free()
	_set_owner(world, world)
	var packed := PackedScene.new()
	var err := packed.pack(world)
	if err == OK:
		err = ResourceSaver.save(packed, path)
	world.free()
	return err


static func _set_owner(node: Node, owner_node: Node) -> void:
	for c in node.get_children():
		c.owner = owner_node
		if c.scene_file_path == "":    # prefab instances (tree, rock...) keep their insides in their own scene
			_set_owner(c, owner_node)


# runs `make` (which adds ONE child to `parent`) and names that child
static func _named(parent: Node, node_name: String, make: Callable) -> void:
	var n := parent.get_child_count()
	make.call()
	if parent.get_child_count() > n:
		parent.get_child(n).name = node_name


static func _ground(world: Node3D, arena: float) -> void:
	var body := StaticBody3D.new()
	body.name = "Ground"
	world.add_child(body)
	var shape := BoxShape3D.new()
	shape.size = Vector3(arena * 2 + 20, 1, arena * 2 + 20)
	var cs := CollisionShape3D.new()
	cs.name = "GroundShape"
	cs.shape = shape
	cs.position.y = -0.5
	body.add_child(cs)
	var mesh := MeshInstance3D.new()
	mesh.name = "GroundMesh"
	var bm := BoxMesh.new()
	bm.size = shape.size
	mesh.mesh = bm
	mesh.position.y = -0.5
	mesh.material_override = Art.ground_material()
	body.add_child(mesh)

	# invisible walls around the edge
	var wall_len := arena * 2 + 20
	var walls := {"WallSouth": Vector3(0, 5, arena + 4), "WallNorth": Vector3(0, 5, -arena - 4),
		"WallEast": Vector3(arena + 4, 5, 0), "WallWest": Vector3(-arena - 4, 5, 0)}
	for wn in walls:
		var s: Vector3 = walls[wn]
		var w := CollisionShape3D.new()
		w.name = wn
		var ws := BoxShape3D.new()
		ws.size = Vector3(wall_len, 10, 2) if s.x == 0.0 else Vector3(2, 10, wall_len)
		w.shape = ws
		w.position = s
		body.add_child(w)


static func _forest(world: Node3D, arena: float, tree_count: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 1337
	var spots: Array[Vector3] = []  # x, scale, z
	while spots.size() < tree_count:
		var p := Vector2(rng.randf_range(-arena, arena), rng.randf_range(-arena, arena))
		if p.length() < 8.0:
			continue  # keep the start clearing free
		var too_close := false
		for o in spots:
			if Vector2(o.x, o.z).distance_to(p) < TREE_MIN_DIST:
				too_close = true   # keep gaps wide enough for zombies to walk between trunks
				break
		if too_close:
			continue
		spots.append(Vector3(p.x, rng.randf_range(0.8, 1.6), p.y))

	# trees: instances of tree.tscn (about 1 in 10 is the bare dead_tree.tscn). The trunk
	# collision is part of the prefab, so there is no separate list of collision shapes.
	var trees := Node3D.new()
	trees.name = "Trees"
	world.add_child(trees)
	var i := 0
	for s in spots:
		var h := fposmod(sin(s.x * 12.9898 + s.z * 78.233) * 43758.5453, 1.0)
		var h2 := fposmod(sin(s.x * 39.3468 + s.z * 11.135) * 24634.6345, 1.0)
		var t: Node3D = (DEAD_TREE if h2 < 0.1 else TREE).instantiate()
		t.name = "Tree%d" % i
		t.transform = Transform3D(Basis(Vector3.UP, h * TAU) * Basis.from_scale(Vector3.ONE * s.y), Vector3(s.x, 0.0, s.z))
		t.set("height_mul", 0.6 + fposmod(h * 7.31 + h2 * 3.17, 1.0) * 1.3)
		trees.add_child(t)
		i += 1

	# grass is thousands of tiny blades, so it is NOT saved as nodes: this node grows them when the scene starts
	var cover := Node3D.new()
	cover.name = "GroundCover"
	cover.set_script(GROUND_COVER)
	cover.set("arena", arena)
	world.add_child(cover)

	_scatter(world, "Rocks", ROCK, Art.QUALITY.rocks, arena, 7.0, 4343, true)
	_scatter(world, "Mushrooms", MUSHROOM, Art.QUALITY.mushrooms, arena, 5.0, 4444, false)


# scatters `count` instances of a prefab over the arena (outside `clear_radius` of the campfire)
static func _scatter(world: Node3D, group_name: String, scene: PackedScene, count: int, arena: float,
		clear_radius: float, seed_: int, rock_like: bool) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_
	var group := Node3D.new()
	group.name = group_name
	world.add_child(group)
	for i in count:
		var p := Vector2(rng.randf_range(-arena, arena), rng.randf_range(-arena, arena))
		while p.length() < clear_radius:
			p = Vector2(rng.randf_range(-arena, arena), rng.randf_range(-arena, arena))
		var n: Node3D = scene.instantiate()
		n.name = "%s%d" % [group_name.trim_suffix("s"), i]
		var yaw := Basis(Vector3.UP, rng.randf() * TAU)
		if rock_like:
			var sc := rng.randf_range(0.5, 1.6)
			var b := yaw * Basis.from_scale(Vector3(sc * rng.randf_range(0.9, 1.6), sc * rng.randf_range(0.5, 0.9), sc * rng.randf_range(0.9, 1.4)))
			n.transform = Transform3D(b, Vector3(p.x, 0.1 * sc, p.y))
		else:
			var sc := rng.randf_range(0.7, 1.8)
			n.transform = Transform3D(Basis.from_scale(Vector3.ONE * sc), Vector3(p.x, 0.0, p.y))
		group.add_child(n)


# nodes made by code get internal names like "@MeshInstance3D@12"; give them clean ones
static func _tidy(node: Node) -> void:
	for c in node.get_children():
		if String(c.name).begins_with("@"):
			c.name = c.get_class()
		if c.scene_file_path == "":   # don't dig into prefab instances
			_tidy(c)
