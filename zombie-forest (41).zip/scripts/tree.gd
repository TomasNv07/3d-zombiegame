extends StaticBody3D
# Conifer tree. height_mul stretches the tree and its hitbox (1.0 = 9 m tall).
# procedural = true builds the tree from the baked meshes in tree_data.gd
# (made by tools/gen_tree.py: a trunk plus whorls of drooping branches with hanging needle sprays).
# procedural = false (dead_tree.tscn) just keeps the meshes that are already in the scene.
@export var height_mul := 1.0
@export var procedural := true

const DATA := preload("res://scripts/tree_data.gd")
const BARK := preload("res://assets/materials/bark.tres")
const NEEDLE_DARK := Color(0.045, 0.14, 0.075)
const NEEDLE_LIGHT := Color(0.12, 0.29, 0.14)

static var _needle_meshes: Array[ArrayMesh] = []
static var _trunk_mesh: ArrayMesh
static var _needle_mat: StandardMaterial3D
static var _bark_mat: StandardMaterial3D


func _ready() -> void:
	if procedural:
		_build_visual()
	elif not is_equal_approx(height_mul, 1.0):
		for c in get_children():
			if c is MeshInstance3D:
				c.position.y *= height_mul
				c.scale.y = height_mul
	if not is_equal_approx(height_mul, 1.0):
		for c in get_children():
			if c is CollisionShape3D and c.shape is CylinderShape3D:
				var sh := (c.shape as CylinderShape3D).duplicate() as CylinderShape3D
				sh.height *= height_mul
				c.shape = sh
				c.position.y *= height_mul


func _build_visual() -> void:
	_init_shared()
	var pick := int(absf(global_position.x * 7.0 + global_position.z * 13.0)) % _needle_meshes.size()
	# taller trees get a little wider too, so they don't look stretched
	var w := lerpf(1.0, height_mul, 0.35)
	var sc := Vector3(w, height_mul, w)
	var needles := MeshInstance3D.new()
	needles.name = "Needles"
	needles.mesh = _needle_meshes[pick]
	needles.scale = sc
	needles.visibility_range_end = 60.0
	needles.rotation.y = float(pick) * 1.7
	add_child(needles)
	var trunk := MeshInstance3D.new()
	trunk.name = "Trunk"
	trunk.mesh = _trunk_mesh
	trunk.scale = sc
	trunk.visibility_range_end = 60.0
	add_child(trunk)


static func _init_shared() -> void:
	if _trunk_mesh != null:
		return
	_needle_mat = StandardMaterial3D.new()
	_needle_mat.vertex_color_use_as_albedo = true
	_needle_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_needle_mat.roughness = 0.9
	_bark_mat = BARK.duplicate() as StandardMaterial3D
	_bark_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_bark_mat.uv1_triplanar = false

	# trunk
	var tv := _decode_vec3(DATA.TRUNK_V, 0.01)
	var tuv := _decode_s16(DATA.TRUNK_UV)
	var uvs := PackedVector2Array()
	for i in range(0, tuv.size(), 2):
		uvs.append(Vector2(tuv[i], tuv[i + 1]) * 0.001)
	var tn := PackedVector3Array()
	for v in tv:
		tn.append(Vector3(v.x, 0.0, v.z).normalized())
	_trunk_mesh = _make_mesh(tv, tn, PackedColorArray(), uvs, _decode_indices(DATA.TRUNK_I), _bark_mat)

	# needle variants
	for item in DATA.NEEDLES:
		var verts := _decode_vec3(item["v"], 0.01)
		var shade := Marshalls.base64_to_raw(item["s"])
		var cols := PackedColorArray()
		var norms := PackedVector3Array()
		for i in verts.size():
			cols.append(NEEDLE_DARK.lerp(NEEDLE_LIGHT, shade[i] / 255.0))
			# soft "round tree" shading: normals point away from the trunk, a bit upward
			var v := verts[i]
			norms.append(Vector3(v.x, 0.35 + v.y * 0.02, v.z).normalized())
		_needle_meshes.append(_make_mesh(verts, norms, cols, PackedVector2Array(), _decode_indices(item["i"]), _needle_mat))


static func _make_mesh(verts: PackedVector3Array, norms: PackedVector3Array, cols: PackedColorArray,
		uvs: PackedVector2Array, idx: PackedInt32Array, mat: Material) -> ArrayMesh:
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	if cols.size() > 0:
		arrays[Mesh.ARRAY_COLOR] = cols
	if uvs.size() > 0:
		arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = idx
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	m.surface_set_material(0, mat)
	return m


static func _decode_s16(b64: String) -> PackedFloat32Array:
	var raw := Marshalls.base64_to_raw(b64)
	var out := PackedFloat32Array()
	out.resize(raw.size() / 2)
	for i in out.size():
		out[i] = raw.decode_s16(i * 2)
	return out


static func _decode_vec3(b64: String, scale: float) -> PackedVector3Array:
	var f := _decode_s16(b64)
	var out := PackedVector3Array()
	out.resize(f.size() / 3)
	for i in out.size():
		out[i] = Vector3(f[i * 3], f[i * 3 + 1], f[i * 3 + 2]) * scale
	return out


static func _decode_indices(b64: String) -> PackedInt32Array:
	var raw := Marshalls.base64_to_raw(b64)
	var out := PackedInt32Array()
	out.resize(raw.size() / 2)
	for i in out.size():
		out[i] = raw.decode_u16(i * 2)
	return out
