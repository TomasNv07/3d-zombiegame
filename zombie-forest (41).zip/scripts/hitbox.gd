extends StaticBody3D
# One body-part hitbox of a zombie (head, torso, an arm or a leg). It follows its bone, so it
# matches the animated pose. Shots/bat hits land here and are forwarded to the zombie together
# with the body part that was actually hit.

var zombie: Node
var zone := "chest"


func hit(dmg: float, point := Vector3.INF, dir := Vector3.ZERO, melee := false) -> void:
	if is_instance_valid(zombie):
		zombie.hit(dmg, point, dir, melee, zone)
