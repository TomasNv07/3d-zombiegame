extends CanvasLayer
const Art := preload("res://scripts/art.gd")
# All UI is built in code: health, ammo, money, wave, banner, shop (E at the cabin window), game over screen.

var root := Control.new()
var health_bar := ProgressBar.new()
var health_label: Label
var weapon_label: Label
var ammo_label: Label
var money_label: Label
var wave_label: Label
var kills_label: Label
var banner: Label
var prompt: Label   # "Press E" hint shown at the shop window
var hurt_rect: TextureRect
var shop_center := CenterContainer.new()
var shop_box := VBoxContainer.new()
var death_rect := ColorRect.new()
var death_label: Label
var shop_open := false
var menu_open := false
var menu_center := CenterContainer.new()
var sens_value: Label
var banner_tween: Tween


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS  # keeps working while the shop pauses the game
	_build_ui()
	Game.changed.connect(_refresh)
	Game.hurt.connect(_on_hurt)
	Game.died.connect(_on_died)
	Game.message.connect(_show_banner)
	_refresh()


func _label(text: String, size: int, color := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	return l


func _corner(ax: float, ay: float) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.anchor_left = ax
	v.anchor_right = ax
	v.anchor_top = ay
	v.anchor_bottom = ay
	var ox := 16.0 if ax == 0.0 else -16.0
	var oy := 16.0 if ay == 0.0 else -16.0
	v.offset_left = ox
	v.offset_right = ox
	v.offset_top = oy
	v.offset_bottom = oy
	v.grow_horizontal = Control.GROW_DIRECTION_END if ax == 0.0 else Control.GROW_DIRECTION_BEGIN
	v.grow_vertical = Control.GROW_DIRECTION_END if ay == 0.0 else Control.GROW_DIRECTION_BEGIN
	root.add_child(v)
	return v


func _full_rect(c: Control) -> void:
	c.anchor_right = 1.0
	c.anchor_bottom = 1.0


func _build_ui() -> void:
	_full_rect(root)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = Art.make_theme()   # all button / panel / bar styling lives in Art.make_theme()
	add_child(root)
	root.add_child(Art.vignette(Color(0, 0, 0, 0.55), 0.45))   # permanent dark edges

	# top-left: health
	var tl := _corner(0.0, 0.0)
	health_label = _label("HP", 22, Color(1, 0.4, 0.4))
	tl.add_child(health_label)
	health_bar.custom_minimum_size = Vector2(240, 18)
	health_bar.show_percentage = false
	tl.add_child(health_bar)

	# top-right: money / wave / kills
	var tr := _corner(1.0, 0.0)
	money_label = _label("", 26, Color(1, 0.9, 0.3))
	wave_label = _label("", 22)
	kills_label = _label("", 18, Color(0.8, 0.8, 0.8))
	for l in [money_label, wave_label, kills_label]:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		tr.add_child(l)

	# bottom-right: weapon + ammo
	var br := _corner(1.0, 1.0)
	weapon_label = _label("", 22)
	ammo_label = _label("", 34, Color(1, 0.95, 0.8))
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	br.add_child(weapon_label)
	br.add_child(ammo_label)

	# bottom-left: controls hint
	var bl := _corner(0.0, 1.0)
	bl.add_child(_label("WASD move | Shift sprint | LMB shoot/swing bat | R reload | F flashlight | 1-5 weapons | E shop (at the cabin window) | Esc menu", 14, Color(0.75, 0.75, 0.75)))

	root.add_child(Art.crosshair())

	# banner
	banner = _label("", 40, Color(1, 0.85, 0.5))
	banner.anchor_right = 1.0
	banner.anchor_top = 0.2
	banner.anchor_bottom = 0.2
	banner.offset_top = -30.0
	banner.offset_bottom = 30.0
	banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner.modulate.a = 0.0
	root.add_child(banner)

	# "Press E" prompt (shown when facing the cabin's shop window)
	prompt = _label("Press E to open the shop", 24, Color(1, 0.9, 0.6))
	prompt.anchor_right = 1.0
	prompt.anchor_top = 0.62
	prompt.anchor_bottom = 0.62
	prompt.offset_top = -20.0
	prompt.offset_bottom = 20.0
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.visible = false
	root.add_child(prompt)

	# red flash when hurt
	hurt_rect = Art.vignette(Color(0.85, 0.0, 0.0, 0.85), 0.25)
	hurt_rect.modulate.a = 0.0
	root.add_child(hurt_rect)

	# shop
	_full_rect(shop_center)
	shop_center.visible = false
	var panel := PanelContainer.new()
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 20)
	shop_box.add_theme_constant_override("separation", 8)
	margin.add_child(shop_box)
	panel.add_child(margin)
	shop_center.add_child(panel)
	root.add_child(shop_center)

	# pause menu (Esc): mouse sensitivity
	_build_menu()

	# game over
	_full_rect(death_rect)
	death_rect.color = Color(0, 0, 0, 0.75)
	death_rect.visible = false
	death_label = _label("", 36, Color(1, 0.3, 0.3))
	death_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	death_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_full_rect(death_label)
	death_rect.add_child(death_label)
	root.add_child(death_rect)


func _refresh() -> void:
	var w: String = Game.current
	health_bar.max_value = Game.max_health
	health_bar.value = Game.health
	var fill := health_bar.get_theme_stylebox("fill") as StyleBoxFlat
	if fill:
		fill.bg_color = Art.health_color(Game.health / Game.max_health)
		fill.border_color = fill.bg_color
	health_label.text = "HP %d" % ceil(Game.health)
	weapon_label.text = Game.WEAPONS[w].name
	if Game.is_melee(w):
		ammo_label.text = "Melee"
	elif Game.reloading:
		ammo_label.text = "Reloading..."
	else:
		ammo_label.text = "%d / %d" % [Game.ammo[w], Game.reserve[w]]
	money_label.text = "$%d" % Game.money
	wave_label.text = "Wave %d" % Game.wave
	kills_label.text = "Kills: %d" % Game.kills
	if shop_open:
		_rebuild_shop()


func _show_banner(text: String) -> void:
	banner.text = text
	banner.modulate.a = 1.0
	if banner_tween:
		banner_tween.kill()
	banner_tween = create_tween()
	banner_tween.tween_interval(2.5)
	banner_tween.tween_property(banner, "modulate:a", 0.0, 0.8)


func _on_hurt() -> void:
	hurt_rect.modulate.a = 1.0
	create_tween().tween_property(hurt_rect, "modulate:a", 0.0, 0.45)


func _on_died() -> void:
	if shop_open:
		_toggle_shop()
	if menu_open:
		_toggle_menu()
	death_label.text = "YOU DIED\n\nWave %d   |   Kills %d\n\nPress Enter to try again" % [Game.wave, Game.kills]
	death_rect.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed and not event.echo):
		return
	if event.keycode == KEY_E and not Game.dead and not menu_open and (shop_open or _at_shop_window()):
		_toggle_shop()
		get_viewport().set_input_as_handled()


func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed and not event.echo):
		return
	if Game.dead:
		if event.keycode == KEY_ENTER or event.keycode == KEY_KP_ENTER:
			Game.reset()
			get_tree().paused = false
			get_tree().reload_current_scene()
		return
	if event.keycode == KEY_ESCAPE:
		if shop_open:
			_toggle_shop()
		else:
			_toggle_menu()
		get_viewport().set_input_as_handled()


const SHOP_REACH := 3.5        # how far (m) in front of the window the shop zone reaches
const SHOP_WIDTH := 2.5        # how far (m) to either side of the window's center
const SHOP_FACING := 0.4       # how much you must look toward the window (dot product, 1 = dead on)


# true when the player stands in the zone in front of the cabin's ShopWindow marker
# (the marker's +X side is the outside) and is looking toward the window
func _at_shop_window() -> bool:
	if Game.dead:
		return false
	var player := get_tree().get_first_node_in_group("player") as Node3D
	if player == null:
		return false
	var cam := player.get_node_or_null("Head/Camera3D") as Camera3D
	if cam == null:
		return false
	# the window marker lives in the cabin scene; find it by group, or by name as a fallback
	var windows: Array = get_tree().get_nodes_in_group("shop_window")
	if windows.is_empty():
		var found := get_tree().root.find_child("ShopWindow", true, false)
		if found:
			windows.append(found)
	for w in windows:
		var m := w as Node3D
		var lp: Vector3 = m.to_local(cam.global_position)
		if lp.x < -0.5 or lp.x > SHOP_REACH or absf(lp.z) > SHOP_WIDTH:
			continue
		var fwd: Vector3 = -cam.global_transform.basis.z
		var inward: Vector3 = -m.global_transform.basis.x.normalized()
		if fwd.dot(inward) >= SHOP_FACING:
			return true
	return false


func _process(_delta: float) -> void:
	prompt.visible = not shop_open and not menu_open and _at_shop_window()


func _build_menu() -> void:
	_full_rect(menu_center)
	menu_center.visible = false
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	_full_rect(dim)
	menu_center.add_child(dim)
	var panel := PanelContainer.new()
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	box.custom_minimum_size = Vector2(380, 0)
	box.add_child(_label("PAUSED", 32, Color(1, 0.85, 0.5)))
	box.add_child(_label("Mouse sensitivity", 20))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var slider := HSlider.new()
	slider.min_value = 0.1
	slider.max_value = 3.0
	slider.step = 0.05
	slider.value = Game.sensitivity
	slider.custom_minimum_size = Vector2(260, 28)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sens_value = _label("%.2fx" % Game.sensitivity, 20, Color(1, 0.95, 0.8))
	slider.value_changed.connect(func(v: float):
		Game.sensitivity = v
		sens_value.text = "%.2fx" % v)
	slider.drag_ended.connect(func(_changed: bool): Game.save_settings())
	row.add_child(slider)
	row.add_child(sens_value)
	box.add_child(row)
	var resume := Button.new()
	resume.text = "Resume  (Esc)"
	resume.pressed.connect(_toggle_menu)
	box.add_child(resume)
	var restart := Button.new()
	restart.text = "Restart game"
	restart.pressed.connect(func():
		Game.reset()
		get_tree().paused = false
		get_tree().reload_current_scene())
	box.add_child(restart)
	margin.add_child(box)
	panel.add_child(margin)
	menu_center.add_child(panel)
	root.add_child(menu_center)


func _toggle_menu() -> void:
	menu_open = not menu_open
	menu_center.visible = menu_open
	get_tree().paused = menu_open
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if menu_open else Input.MOUSE_MODE_CAPTURED
	if not menu_open:
		Game.save_settings()


func _toggle_shop() -> void:
	shop_open = not shop_open
	shop_center.visible = shop_open
	get_tree().paused = shop_open
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if shop_open else Input.MOUSE_MODE_CAPTURED
	if shop_open:
		_rebuild_shop()


func _rebuild_shop() -> void:
	for c in shop_box.get_children():
		shop_box.remove_child(c)
		c.queue_free()
	shop_box.add_child(_label("UPGRADE SHOP   (B to close)", 28))
	shop_box.add_child(_label("Money: $%d" % Game.money, 22, Color(1, 0.9, 0.3)))

	for w in Game.ORDER:
		var d: Dictionary = Game.WEAPONS[w]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		var title := _label(d.name + ("  [equipped]" if Game.current == w else ""), 18)
		title.custom_minimum_size.x = 190
		row.add_child(title)
		if not Game.owned.has(w):
			var buy := Button.new()
			buy.text = "Buy  $%d" % d.price
			buy.disabled = Game.money < d.price
			buy.pressed.connect(func(): Game.buy_weapon(w))
			row.add_child(buy)
		else:
			var eq := Button.new()
			eq.text = "Equip"
			eq.disabled = Game.current == w
			eq.pressed.connect(func(): Game.equip(w))
			row.add_child(eq)
			for key in ([] if Game.is_melee(w) else Game.UPGRADES):
				var lvl: int = Game.levels[w][key]
				var btn := Button.new()
				if lvl >= Game.MAX_LEVEL:
					btn.text = "%s MAX" % Game.UPGRADES[key]
					btn.disabled = true
				else:
					var cost := Game.upgrade_cost(w, key)
					btn.text = "%s L%d  $%d" % [Game.UPGRADES[key], lvl + 1, cost]
					btn.disabled = Game.money < cost
				btn.pressed.connect(func(): Game.buy_upgrade(w, key))
				row.add_child(btn)
		shop_box.add_child(row)

	var med := Button.new()
	med.text = "Medkit +50 HP  $100"
	med.disabled = Game.money < 100 or Game.health >= Game.max_health
	med.pressed.connect(func(): Game.buy_medkit())
	shop_box.add_child(med)
