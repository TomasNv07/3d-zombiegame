extends CharacterBody3D
# Zombie logic only. The body is the skinned model assets/models/zombie.gltf (bones + animations),
# loaded into the Visual node at start. This script recolors it per zombie and plays its animations.
# Chases the player, hits when close, drops money + ammo loot when killed.

const Art := preload("res://scripts/art.gd")
const Loot := preload("res://scripts/loot.gd")
const Ragdoll := preload("res://scripts/ragdoll.gd")
const Hitbox := preload("res://scripts/hitbox.gd")

# per-bone hitboxes (bone space): size, offset, damage zone. Match the shapes of the model's body parts.
const HITBOXES := {
	"Head": {"size": Vector3(0.36, 0.36, 0.36), "off": Vector3.ZERO, "zone": "head"},
	"Torso": {"size": Vector3(0.52, 0.75, 0.34), "off": Vector3(0, 0.4, 0), "zone": "chest"},
	"ArmL": {"size": Vector3(0.17, 0.17, 0.78), "off": Vector3(0, 0, -0.4), "zone": "chest"},
	"ArmR": {"size": Vector3(0.17, 0.17, 0.78), "off": Vector3(0, 0, -0.4), "zone": "chest"},
	"LegL": {"size": Vector3(0.26, 0.86, 0.28), "off": Vector3(0, -0.42, 0), "zone": "leg"},
	"LegR": {"size": Vector3(0.26, 0.86, 0.28), "off": Vector3(0, -0.42, 0), "zone": "leg"},
}
var hitboxes: Array = []

const HEADSHOT_KILL_WAVES := 3   # normal zombies up to this wave die to a single headshot
const HEAD_HEIGHT := 1.6         # hit point above this (x body_scale) counts as a head shot
const LEG_HEIGHT := 0.95         # hit point below this (x body_scale) counts as a leg shot, in between = chest

# What a hit that does NOT kill does, by where it landed (the dying throw is in ragdoll.gd -> PROFILES)
const KNOCKBACK := {"head": 1.5, "chest": 3.5, "leg": 1.0}   # m/s shove away from the shot (x weapon power)
const STUN := {"head": 0.3, "chest": 0.12, "leg": 0.0}       # seconds it stops to stagger (can't move or bite)
const LIMP_TIME := 1.4           # a leg hit makes it limp for this many seconds...
const LIMP_SPEED := 0.45         # ...at this fraction of its normal speed
const WINDUP := 0.5              # seconds a zombie must stay close to you before its hit lands
const BAT_KNOCKBACK := 11.0      # m/s shove from the metal bat (x resistance)
const BAT_STUN := 0.7
const RAGDOLL := true            # false = old behaviour (plain death animation)

var health := 50.0
var max_health := 50.0
var speed := 2.5
var damage := 10.0
var reward := 10
var body_scale := 1.0
var kind := "normal"
var skin_color := Color(0.46, 0.5, 0.4)
var dead := false
var head_kill := false
var attack_cd := 0.6
var skin: StandardMaterial3D       # flashed when hit
var player: Node3D
var anim: AnimationPlayer           # set when the skinned model (assets/models/zombie.gltf) is used
var skeleton: Skeleton3D
var knock := Vector3.ZERO           # extra velocity from being shot, fades out
var stun_t := 0.0
var windup_t := 0.0                 # how long it has been winding up a hit
var limp_t := 0.0
var volley_t := -1.0                # shotgun pellets arrive together: add their damage up for the death throw
var volley_dmg := 0.0
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

@onready var visual: Node3D = $Visual


# Call before add_child(): picks stats by wave number and zombie kind.
func setup(wave: int, zombie_kind: String) -> void:
	kind = zombie_kind
	max_health = 40.0 + wave * 12.0
	speed = minf(2.3 + wave * 0.12, 3.8) + randf() * 0.6
	match kind:
		"runner":
			max_health *= 0.6
			speed *= 1.7
			body_scale = 0.9
			skin_color = Color(0.55, 0.5, 0.32)
			reward = 15
		"tank":
			max_health *= 4.0
			speed *= 0.7
			damage = 20.0
			body_scale = 1.45
			skin_color = Color(0.36, 0.4, 0.5)
			reward = 40
	health = max_health
	head_kill = kind == "normal" and wave <= HEADSHOT_KILL_WAVES


func _ready() -> void:
	var model_root := Art.model("zombie_" + kind)
	if model_root == null:
		model_root = Art.model("zombie")
	if model_root == null:
		push_error("Zombie model missing: open the project in the Godot editor once so assets/models/zombie.gltf gets imported.")
	else:
		visual.add_child(model_root)
		_setup_skinned(model_root)
	visual.scale = Vector3.ONE * body_scale

	# collision capsule lives in zombie.tscn; copy it so each zombie can have its own size
	var cap := ($CollisionShape3D.shape as CapsuleShape3D).duplicate() as CapsuleShape3D
	cap.radius = 0.4 * body_scale
	cap.height = 1.9 * body_scale
	$CollisionShape3D.shape = cap
	$CollisionShape3D.position.y = 0.95 * body_scale


# Skinned model: recolor per zombie, pick the kind's extras, and start the bone animations.
func _setup_skinned(model_root: Node3D) -> void:
	var copies := {}
	var by_name := {}
	for m in model_root.find_children("*", "MeshInstance3D", true, false):
		for i in m.mesh.get_surface_count():
			var old: Material = m.get_active_material(i)
			if old == null:
				continue
			if not copies.has(old):
				var c := old.duplicate()
				copies[old] = c
				by_name[c.resource_name] = c
			m.set_surface_override_material(i, copies[old])
	if by_name.has("Skin"):
		skin = by_name["Skin"]
		skin.albedo_color = _tint(skin_color, randf_range(0.85, 1.15))
		skin.emission_enabled = true
		skin.emission = Color(1.0, 0.1, 0.1)
		skin.emission_energy_multiplier = 0.0
	if by_name.has("SkinDark"):
		by_name["SkinDark"].albedo_color = _tint(skin_color, 0.6)
	if by_name.has("Shirt"):
		by_name["Shirt"].albedo_color = _tint(skin_color, 0.7) if kind == "runner" else Art.SHIRTS[randi() % Art.SHIRTS.size()]
	if by_name.has("Pants"):
		by_name["Pants"].albedo_color = Art.PANTS[randi() % Art.PANTS.size()]
	if kind == "runner" and by_name.has("Eye"):
		by_name["Eye"].albedo_color = Color(1.0, 0.85, 0.15)
		by_name["Eye"].emission = Color(1.0, 0.85, 0.15)
	var plates := model_root.find_child("TankPlates", true, false)
	if plates:
		plates.visible = kind == "tank"
	var hair := model_root.find_child("Hair", true, false)
	if hair:
		hair.visible = randf() < 0.7
	var skels := model_root.find_children("*", "Skeleton3D", true, false)
	if skels.size() > 0:
		skeleton = skels[0]
		_add_hitboxes()
	var players := model_root.find_children("*", "AnimationPlayer", true, false)
	if players.size() > 0:
		anim = players[0]
		for n in ["walk", "idle"]:
			if anim.has_animation(n):
				anim.get_animation(n).loop_mode = Animation.LOOP_LINEAR
		anim.play("walk" if anim.has_animation("walk") else anim.get_animation_list()[0])
		anim.seek(randf() * 0.9)   # so a crowd doesn't march in sync


# Hitboxes follow the bones (BoneAttachment3D), so shots hit the body parts as they are animated.
func _add_hitboxes() -> void:
	for bone_name in HITBOXES:
		if skeleton.find_bone(bone_name) < 0:
			continue
		var d: Dictionary = HITBOXES[bone_name]
		var att := BoneAttachment3D.new()
		att.name = "Hit" + bone_name
		att.bone_name = bone_name
		skeleton.add_child(att)
		var hb := Hitbox.new()
		hb.zombie = self
		hb.zone = d.zone
		hb.collision_layer = 2    # layer the player's bullets / bat look for
		hb.collision_mask = 0
		var cs := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = d.size
		cs.shape = box
		cs.position = d.off
		hb.add_child(cs)
		att.add_child(hb)
		hitboxes.append(hb)


func _tint(c: Color, f: float) -> Color:
	return Color(c.r * f, c.g * f, c.b * f)


func _physics_process(delta: float) -> void:
	if dead:
		return
	if not is_on_floor():
		velocity.y -= gravity * delta
	if player == null:
		player = get_tree().get_first_node_in_group("player")
	attack_cd -= delta
	stun_t -= delta
	limp_t -= delta
	knock = knock.lerp(Vector3.ZERO, 1.0 - exp(-6.0 * delta))

	if player == null or Game.dead:
		velocity.x = knock.x
		velocity.z = knock.z
		move_and_slide()
		return

	var to := player.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	var dir := to / maxf(dist, 0.001)

	if stun_t > 0.0:    # staggering: pushed around, can't walk or bite
		windup_t = 0.0
		velocity.x = knock.x
		velocity.z = knock.z
		move_and_slide()
		return

	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 10.0 * delta)
	var run := speed * (LIMP_SPEED if limp_t > 0.0 else 1.0)

	if dist > 1.3 * body_scale:
		var wdir := dir
		if is_on_wall():   # blocked by a tree: slide along it instead of pushing into it
			var n := get_wall_normal()
			n.y = 0.0
			if n.length() > 0.01:
				n = n.normalized()
				var tangent := Vector3(-n.z, 0.0, n.x)
				if tangent.dot(dir) < 0.0:
					tangent = -tangent
				wdir = (tangent * 0.9 + n * 0.3).normalized()
		velocity.x = wdir.x * run + knock.x
		velocity.z = wdir.z * run + knock.z
		_animate_walk(delta, run)
	else:
		velocity.x = knock.x
		velocity.z = knock.z
		_play("idle")
	move_and_slide()

	# attack: needs to stay close for WINDUP seconds before the hit lands (leave range = it starts over)
	if dist < 1.8 * body_scale and attack_cd <= 0.0:
		if windup_t <= 0.0:
			_lunge()                       # start the swing animation
		windup_t += delta
		if windup_t >= WINDUP:
			windup_t = 0.0
			attack_cd = 1.0
			if dist < 2.1 * body_scale:    # still in reach when the swing lands
				Game.hurt_player(damage)
	elif dist >= 2.1 * body_scale:
		windup_t = 0.0


# play a bone animation (only when the skinned model is in use)
func _play(anim_name: String, blend := 0.2) -> void:
	if anim == null or not anim.has_animation(anim_name):
		return
	if anim.current_animation == anim_name:
		return
	if anim.current_animation == "attack" and anim.is_playing() and anim_name != "death":
		return   # let the swing finish
	anim.speed_scale = 1.0
	anim.play(anim_name, blend)


func _animate_walk(_delta: float, run := -1.0) -> void:
	if anim == null:
		return
	_play("walk")
	if anim.current_animation == "walk":
		anim.speed_scale = (speed if run < 0.0 else run) * 0.4   # stride rate follows the zombie's speed


func _lunge() -> void:
	if anim and anim.has_animation("attack"):
		anim.speed_scale = 1.0
		anim.play("attack", 0.05)
		return


# dir = the way the bullet was travelling (player.gd passes it); point = where it hit
func hit(dmg: float, point := Vector3.INF, dir := Vector3.ZERO, melee := false, zone_hit := "") -> void:
	if dead:
		return
	if dir == Vector3.ZERO:
		dir = -global_transform.basis.z if player == null else (global_position - player.global_position).normalized()
	var zone := zone_hit if zone_hit != "" else _zone(point)
	var raw_dmg := dmg
	if zone == "head":
		dmg *= 2.5                      # headshot bonus (no more instant kills)
	health -= dmg
	if point != Vector3.INF:
		Art.spawn_blood(get_tree().current_scene, point + dir.normalized() * 0.18, dir, global_position.y, zone == "head" or health <= 0.0)
	if skin:
		skin.emission_energy_multiplier = 2.0
		create_tween().tween_property(skin, "emission_energy_multiplier", 0.0, 0.15)

	# one volley (a shotgun blast = 8 pellets in the same instant) counts as one big hit for the death throw
	var now := Time.get_ticks_msec() / 1000.0
	if now - volley_t > 0.06:
		volley_dmg = 0.0
	volley_t = now
	volley_dmg += raw_dmg
	var resist := pow(body_scale, 1.5)   # tanks are harder to throw around

	if health <= 0.0:
		var power := clampf(volley_dmg / 30.0, 0.5, 2.5)
		if melee:
			power = 2.5    # bat kills send the body flying
		_die(zone, dir, power / resist)
		return

	if melee:    # bat: big shove + long stagger, whatever the body part
		var bpush := dir
		bpush.y = 0.0
		knock += bpush.normalized() * BAT_KNOCKBACK / resist
		knock = knock.limit_length(14.0)
		stun_t = maxf(stun_t, BAT_STUN)
		windup_t = 0.0
		return

	# still alive: shoved, staggered or slowed depending on where it was hit
	var push := dir
	push.y = 0.0
	knock += push.normalized() * KNOCKBACK[zone] * clampf(raw_dmg / 30.0, 0.15, 2.0) / resist
	knock = knock.limit_length(7.0)
	stun_t = maxf(stun_t, STUN[zone])
	if zone == "leg":
		limp_t = LIMP_TIME


# "head", "chest" or "leg", from the height of the hit point
func _zone(point: Vector3) -> String:
	if point == Vector3.INF:
		return "chest"
	var h := (point.y - global_position.y) / body_scale
	if h >= HEAD_HEIGHT:
		return "head"
	if h < LEG_HEIGHT:
		return "leg"
	return "chest"


func _die(zone: String, dir: Vector3, power: float) -> void:
	dead = true
	remove_from_group("zombies")
	Game.add_kill()
	$CollisionShape3D.set_deferred("disabled", true)
	for hb in hitboxes:
		if is_instance_valid(hb):
			hb.collision_layer = 0   # corpses no longer block shots
	_drop_loot()
	if RAGDOLL and skeleton != null:
		if anim:
			anim.active = false    # stop the walk animation: the physics bodies drive the bones now
		var rd := Ragdoll.new()
		get_tree().current_scene.add_child(rd)
		rd.start(self, skeleton, zone, dir, power, Vector3(velocity.x, 0.0, velocity.z) * 0.8, body_scale)
		return                     # the ragdoll removes this zombie when the corpse has sunk away
	var t := create_tween()
	if anim and anim.has_animation("death"):
		anim.speed_scale = 1.0
		anim.play("death", 0.05)
	else:
		t.tween_property(visual, "rotation:x", -PI / 2.0, 0.35)   # only if the model has no death animation
	t.tween_interval(1.5)
	t.tween_callback(queue_free)


# money always drops (tougher zombies drop several piles), ammo drops sometimes
func _drop_loot() -> void:
	var scene := get_tree().current_scene
	var origin := global_position + Vector3(0, 1.1 * body_scale, 0)
	var piles := 1 if kind == "normal" else (2 if kind == "runner" else 3)
	for i in piles:
		var l = Loot.new()
		l.type = "money"
		l.amount = maxi(1, int(round(float(reward) / piles)))
		scene.add_child(l)
		l.launch(origin, global_position.y)
	if randf() < Game.ammo_drop_chance():
		var w := Game.pick_ammo_weapon()
		var l = Loot.new()
		l.type = "ammo"
		l.weapon = w
		l.amount = Game.ammo_drop_amount(w)
		scene.add_child(l)
		l.launch(origin, global_position.y)
