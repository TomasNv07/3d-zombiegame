extends Node3D
# A pickup dropped by a zombie: "money" or "ammo". Pops out of the zombie in an arc, bounces,
# then hovers and spins on the ground until you walk close enough to grab it.
# Look comes from Art.build_loot(); set type/amount(/weapon) before add_child, then call launch().

const Art := preload("res://scripts/art.gd")

const PICKUP_RADIUS := 3.2   # ammo: generous hitbox so it's easy to grab
const LIFETIME := 30.0
const HOVER := 0.4

var type := "money"
var amount := 10
var weapon := "pistol"

var body: Node3D
var light: OmniLight3D
var player: Node3D

var start_pos := Vector3.ZERO
var land_pos := Vector3.ZERO
var ground_y := 0.0
var fly_t := 0.0
var fly_time := 0.55
var landed := false
var bounce_i := 0
var bounce_t := 0.0
var age := 0.0
var collecting := false
var collect_t := 0.0
var bob_phase := randf() * TAU
var spin := 0.0
var _hop_height := 1.1


func _ready() -> void:
	body = Node3D.new()
	add_child(body)
	body.add_child(Art.build_loot(type))
	var col := Art.loot_color(type)
	light = OmniLight3D.new()
	light.light_color = col
	light.light_energy = 0.0
	light.omni_range = 3.5
	light.shadow_enabled = false
	add_child(light)
	body.scale = Vector3.ONE * 0.2


# origin = where it bursts from (zombie chest); floor_y = ground height under the zombie
func launch(origin: Vector3, floor_y: float) -> void:
	ground_y = floor_y
	start_pos = origin
	var ang := randf() * TAU
	var dist := randf_range(0.9, 2.2)
	land_pos = Vector3(origin.x + cos(ang) * dist, floor_y + HOVER, origin.z + sin(ang) * dist)
	fly_time = randf_range(0.5, 0.65)
	global_position = origin
	spin = randf_range(10.0, 16.0) * (1.0 if randf() < 0.5 else -1.0)


func _process(delta: float) -> void:
	age += delta
	if player == null:
		player = get_tree().get_first_node_in_group("player")

	if collecting:
		_update_collect(delta)
		return

	if not landed:
		_update_flight(delta)
	else:
		_update_idle(delta)
		_check_pickup()

	# fade out near the end of its life: blink, then vanish
	if age > LIFETIME - 6.0:
		var rate := 6.0 if age < LIFETIME - 2.0 else 16.0
		body.visible = int(age * rate) % 2 == 0
	if age >= LIFETIME:
		queue_free()


func _update_flight(delta: float) -> void:
	fly_t += delta / fly_time
	var k := minf(fly_t, 1.0)
	var pos := start_pos.lerp(land_pos, k)
	# parabola on top of the lerp: pops up high, falls down to the landing point
	pos.y += 4.0 * _hop_height * k * (1.0 - k)
	global_position = pos
	body.rotation.y += spin * delta
	body.rotation.x = sin(k * PI) * 0.6
	if bounce_i == 0:
		var s := 0.2 + 0.8 * ease(minf(k * 2.0, 1.0), -2.0)   # pops from small to full size
		body.scale = Vector3.ONE * s
		light.light_energy = 1.2 * k
	if fly_t >= 1.0:
		_land()


func _land() -> void:
	# money is grabbed instantly: right after its pop it flies straight into you
	if type == "money" and not Game.dead:
		collecting = true
		collect_t = 0.0
		body.visible = true
		return
	bounce_i += 1
	# little rebounds: each one is lower and quicker than the last
	if bounce_i <= 2:
		fly_t = 0.0
		start_pos = land_pos
		fly_time = 0.28 / bounce_i
		var hop := 0.5 / bounce_i
		_hop_height = hop
		Art.burst(get_tree().current_scene, Vector3(land_pos.x, ground_y + 0.05, land_pos.z), Art.loot_color(type).darkened(0.2), 6, 1.6)
		return
	landed = true
	age = maxf(age, 0.0)
	body.rotation.x = 0.0
	body.scale = Vector3.ONE
	Art.burst(get_tree().current_scene, Vector3(land_pos.x, ground_y + 0.05, land_pos.z), Art.loot_color(type), 8, 1.2)



func _update_idle(delta: float) -> void:
	bob_phase += delta * 3.0
	body.position.y = sin(bob_phase) * 0.06
	body.rotation.y += delta * 1.8
	body.scale = Vector3.ONE * (1.0 + sin(bob_phase * 1.3) * 0.03)
	light.light_energy = 1.2 + sin(bob_phase * 2.0) * 0.25


func _check_pickup() -> void:
	if player == null or Game.dead:
		return
	var d := (player.global_position + Vector3(0, 0.9, 0)).distance_to(global_position)
	if d < PICKUP_RADIUS:
		# ammo for a full gun stays on the floor
		if type == "ammo" and Game.reserve[weapon] >= Game.reserve_cap(weapon):
			return
		collecting = true
		collect_t = 0.0
		body.visible = true


func _update_collect(delta: float) -> void:
	if player == null:
		_give()
		return
	collect_t += delta / 0.22
	var target := player.global_position + Vector3(0, 1.1, 0)
	global_position = global_position.lerp(target, clampf(collect_t * collect_t + delta * 10.0, 0.0, 1.0))
	body.rotation.y += 20.0 * delta
	body.scale = Vector3.ONE * maxf(1.0 - collect_t, 0.05)
	light.light_energy = lerpf(light.light_energy, 3.0, 0.3)
	if collect_t >= 1.0:
		_give()


func _give() -> void:
	var scene := get_tree().current_scene
	var pos := global_position
	var col := Art.loot_color(type)
	if type == "money":
		Game.add_money(amount)
	else:
		Game.add_ammo(weapon, amount)
	Art.burst(scene, pos, col, 12, 3.0)
	queue_free()
