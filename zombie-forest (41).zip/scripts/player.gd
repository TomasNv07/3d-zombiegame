extends CharacterBody3D
# WASD move (with momentum), Shift sprint (forward only), no jumping, mouse look, LMB shoot, R reload, F flashlight,
# 1-4 switch weapon, E at the cabin window = shop (handled by HUD), Esc menu (sensitivity).

const Art := preload("res://scripts/art.gd")

const SPEED := 3.6
const SPRINT_SPEED := 5.6
# movement feel: speed ramps up/down instead of snapping
const WALK_ACCEL := 12.0        # m/s^2 getting up to walking speed
const SPRINT_ACCEL := 8.0      # heavier to get going when sprinting
const BRAKE := 30.0             # reversing / changing direction hard (feet need to dig in)
const FRICTION := 13.0          # coasting to a stop when you let go
const AIR_CONTROL := 0.1        # barely any steering when not on the ground
const BACK_SPEED := 0.6         # backpedalling is slow
const STRAFE_SPEED := 0.85      # sidestepping is a bit slower than running forward
const MOUSE_SENSITIVITY := 0.003

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var cooldown := 0.0
var reload_left := 0.0
var was_down := false
var shown_weapon := ""
var gun := Node3D.new()      # holder; the actual model comes from Art.build_gun()
var gun_model: Node3D
var flash: MeshInstance3D
var muzzle := OmniLight3D.new()
var gun_pos := Vector3.ZERO

# ---- procedural gun animation state ----
var recoil := 0.0            # 0..~1.5, jumps on each shot, decays fast
var cam_kick := 0.0          # camera pitch kick (radians), decays
var sway := Vector2.ZERO     # smoothed gun lag behind mouse look
var mouse_delta := Vector2.ZERO
var bob_t := 0.0
var bob_amt := 0.0
var draw_t := 1.0            # 0 = just switched (gun lowered), 1 = ready
var reload_total := 1.0
var pump_t := -1.0           # shotgun pump progress, <0 = idle
var slide_t := 0.0           # pistol slide / smg bolt kick
var land_dip := 0.0
var step_t := 0.0            # walk-cycle phase (radians), advances with distance walked
var step_amt := 0.0          # 0..1 how much walking motion is shown
var head_rest_y := 1.6
var base_fov := 75.0
var was_on_floor := true
var part_rest := {}          # node name -> rest position of animated parts

# per-weapon feel: kick back (m), muzzle climb (rad), camera kick (rad), side jitter
const FEEL := {
	"pistol": {"back": 0.07, "rot": 0.10, "cam": 0.012, "side": 0.004},
	"smg": {"back": 0.035, "rot": 0.045, "cam": 0.006, "side": 0.008},
	"shotgun": {"back": 0.14, "rot": 0.22, "cam": 0.03, "side": 0.006},
	"rifle": {"back": 0.06, "rot": 0.08, "cam": 0.012, "side": 0.005},
	"bat": {"back": 0.0, "rot": 0.0, "cam": 0.0, "side": 0.0},
}

const BAT_RANGE := 2.6          # how far the bat reaches (m)
const BAT_HIT_TIME := 0.13      # seconds into the swing when it connects
const BAT_SWING_TIME := 0.42    # total swing animation length
var swing_t := -1.0             # <0 = not swinging
var swing_hit_done := false

@onready var head: Node3D = $Head
@onready var ray: RayCast3D = $Head/Camera3D/RayCast3D
@onready var flashlight: SpotLight3D = $Head/Camera3D/Flashlight
@onready var camera: Camera3D = $Head/Camera3D


func _ready() -> void:
	_add_key("move_forward", KEY_W)
	_add_key("move_back", KEY_S)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	ray.add_exception(self)
	head_rest_y = head.position.y
	base_fov = camera.fov

	camera.add_child(gun)
	muzzle.light_color = Color(1.0, 0.7, 0.3)
	muzzle.light_energy = 0.0
	muzzle.omni_range = 8.0
	gun.add_child(muzzle)
	flash = Art.muzzle_flash()
	gun.add_child(flash)

	Game.changed.connect(_on_game_changed)
	_apply_weapon()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _add_key(action: String, key: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = key
	InputMap.action_add_event(action, ev)


func _on_game_changed() -> void:
	if Game.current != shown_weapon:
		_apply_weapon()
	# picked up ammo while the magazine was empty: reload automatically
	if not Game.dead and not Game.reloading and Game.ammo[Game.current] <= 0 and Game.reserve[Game.current] > 0:
		start_reload()


func _apply_weapon() -> void:
	shown_weapon = Game.current
	swing_t = -1.0
	reload_left = 0.0
	Game.reloading = false
	draw_t = 0.0
	pump_t = -1.0
	slide_t = 0.0
	recoil = 0.0
	var size: Vector3 = Game.WEAPONS[shown_weapon].size
	if gun_model:
		gun.remove_child(gun_model)
		gun_model.queue_free()
	gun_model = Art.build_gun(shown_weapon, size)
	gun.add_child(gun_model)
	part_rest.clear()
	for n in ["Slide", "Mag", "Pump"]:
		var part := gun_model.find_child(n, true, false)
		if part:
			part_rest[n] = part.position
	gun_pos = Vector3(0.28, -0.24, -0.3 - size.z * 0.5)
	gun.position = gun_pos
	var tip := Art.muzzle_tip(shown_weapon, size)
	muzzle.position = tip + Vector3(0, 0, -0.05)
	flash.position = tip


func _unhandled_input(event: InputEvent) -> void:
	if Game.dead:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		mouse_delta += event.relative
		rotate_y(-event.relative.x * MOUSE_SENSITIVITY * Game.sensitivity)
		head.rotate_x(-event.relative.y * MOUSE_SENSITIVITY * Game.sensitivity)
		head.rotation.x = clamp(head.rotation.x, deg_to_rad(-89), deg_to_rad(89))
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			was_down = true  # this click only recaptures the mouse, it doesn't shoot
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_R:
				start_reload()
			KEY_F:
				flashlight.visible = not flashlight.visible
			_:
				var idx: int = event.keycode - KEY_1
				if idx >= 0 and idx < Game.ORDER.size():
					Game.equip(Game.ORDER[idx])


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	if Game.dead:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	# sprinting only works while moving mostly forward
	var sprinting_now := Input.is_physical_key_pressed(KEY_SHIFT) and input_dir.y < -0.1
	var speed := SPRINT_SPEED if sprinting_now else SPEED
	# local wish direction: backwards and sideways are slower than forwards
	var local := Vector3(input_dir.x * STRAFE_SPEED, 0.0, input_dir.y * (BACK_SPEED if input_dir.y > 0.0 else 1.0))
	var wish := transform.basis * local * speed     # target velocity (m/s)
	var hvel := Vector2(velocity.x, velocity.z)
	var target := Vector2(wish.x, wish.z)
	var rate: float
	if input_dir == Vector2.ZERO:
		rate = FRICTION
	elif hvel.dot(target) < 0.0 or (hvel.length() > 0.5 and hvel.normalized().dot(target.normalized()) < 0.5):
		rate = BRAKE                                # reversing or sharp turn: lose speed fast first
	else:
		rate = SPRINT_ACCEL if sprinting_now else WALK_ACCEL
	if hvel.length() > target.length() and input_dir != Vector2.ZERO:
		rate = maxf(rate, FRICTION)                 # slowing from a sprint down to a walk
	if not is_on_floor():
		rate *= AIR_CONTROL
	hvel = hvel.move_toward(target, rate * delta)
	velocity.x = hvel.x
	velocity.z = hvel.y
	move_and_slide()

	cooldown = maxf(cooldown - delta, 0.0)
	if Game.reloading:
		reload_left -= delta
		if reload_left <= 0.0:
			Game.reloading = false
			var cur: String = Game.current
			var take: int = mini(Game.mag(cur) - Game.ammo[cur], Game.reserve[cur])
			Game.ammo[cur] += take
			Game.reserve[cur] -= take
			Game.changed.emit()

	var down := Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	var w: String = Game.current
	if down and cooldown <= 0.0 and not Game.reloading and (Game.WEAPONS[w].auto or not was_down):
		if Game.is_melee(w):
			start_swing(w)
		else:
			fire(w)
	if swing_t >= 0.0:
		swing_t += delta
		if not swing_hit_done and swing_t >= BAT_HIT_TIME:
			swing_hit_done = true
			_bat_hit(Game.damage(w))
		if swing_t >= BAT_SWING_TIME:
			swing_t = -1.0
	was_down = down


func start_reload() -> void:
	var w: String = Game.current
	if Game.reloading or Game.ammo[w] >= Game.mag(w):
		return
	if Game.reserve[w] <= 0:
		if Game.ammo[w] <= 0:
			Game.message.emit("Out of ammo! Pick up ammo drops")
		return
	Game.reloading = true
	reload_left = Game.reload_time(w)
	reload_total = maxf(reload_left, 0.01)
	Game.changed.emit()


func start_swing(w: String) -> void:
	cooldown = Game.interval(w)
	swing_t = 0.0
	swing_hit_done = false


# Bat hit: first try exactly where the crosshair points (so headshots are aimable),
# otherwise whack any zombie in front of you within reach.
func _bat_hit(dmg: float) -> void:
	var cam_fwd := -camera.global_transform.basis.z
	var target: Node = null
	var point := Vector3.ZERO
	ray.target_position = Vector3(0, 0, -BAT_RANGE)
	ray.force_raycast_update()
	if ray.is_colliding():
		var col = ray.get_collider()
		if col != null and col.has_method("hit"):
			target = col
			point = ray.get_collision_point()
	if target == null:
		var best := 999.0
		for z in get_tree().get_nodes_in_group("zombies"):
			if z.dead:
				continue
			var chest: Vector3 = z.global_position + Vector3(0, 1.2 * z.body_scale, 0)
			var to: Vector3 = chest - camera.global_position
			var d := to.length()
			if d > BAT_RANGE + 0.4 * z.body_scale or d < 0.01:
				continue
			if to.normalized().dot(cam_fwd) < 0.6:
				continue
			if d < best:
				best = d
				target = z
				point = chest
	if target != null:
		var dir := cam_fwd
		target.hit(dmg, point, dir, true)
		cam_kick += 0.03
	ray.target_position = Vector3(0, 0, -100)


func fire(w: String) -> void:
	if Game.ammo[w] <= 0:
		cooldown = 0.4
		start_reload()
		return
	Game.ammo[w] -= 1
	cooldown = Game.interval(w)
	var d: Dictionary = Game.WEAPONS[w]
	for i in range(d.pellets):
		_shoot_ray(d.spread, Game.damage(w))

	muzzle.light_energy = 1.6
	create_tween().tween_property(muzzle, "light_energy", 0.0, 0.07)
	flash.visible = true
	flash.rotation.z = randf() * TAU
	flash.scale = Vector3.ONE * randf_range(0.8, 1.3) * (1.6 if w == "shotgun" else 1.0)
	get_tree().create_timer(0.05).timeout.connect(flash.hide)
	var f: Dictionary = FEEL[w]
	recoil = minf(recoil + 1.0, 1.6) if Game.WEAPONS[w].auto else 1.0
	cam_kick += f.cam * randf_range(0.8, 1.2)
	slide_t = 1.0
	if w == "shotgun":
		pump_t = -0.25  # short delay, then the pump cycles

	Game.changed.emit()
	if Game.ammo[w] <= 0:
		start_reload()


func _shoot_ray(spread: float, dmg: float) -> void:
	ray.target_position = Vector3(randf_range(-spread, spread), randf_range(-spread, spread), -1.0).normalized() * 100.0
	ray.force_raycast_update()
	if not ray.is_colliding():
		return
	var col = ray.get_collider()
	var is_zombie: bool = col != null and col.has_method("hit")
	if is_zombie:
		col.hit(dmg, ray.get_collision_point(), (ray.get_collision_point() - ray.global_position).normalized())
	if not is_zombie:
		Art.spawn_impact(get_tree().current_scene, ray.get_collision_point(), ray.get_collision_normal(), false)


func _process(delta: float) -> void:
	_animate_gun(delta)


func _animate_gun(delta: float) -> void:
	if gun_model == null:
		return
	var w: String = shown_weapon
	var f: Dictionary = FEEL[w]

	# --- decay timers ---
	recoil = lerpf(recoil, 0.0, 1.0 - exp(-delta * (22.0 if Game.WEAPONS[w].auto else 14.0)))
	cam_kick = lerpf(cam_kick, 0.0, 1.0 - exp(-delta * 12.0))
	slide_t = maxf(slide_t - delta * 9.0, 0.0)
	draw_t = minf(draw_t + delta / 0.4, 1.0)
	if pump_t > -1.0 and w == "shotgun":
		pump_t += delta / 0.45
		if pump_t >= 1.0:
			pump_t = -1.0
	else:
		pump_t = -1.0

	# --- movement bob (stronger when sprinting, none in air) ---
	var hspeed := Vector2(velocity.x, velocity.z).length()
	var on_floor := is_on_floor()
	var sprinting := hspeed > SPEED + 0.5
	var target_bob := 0.0
	if on_floor and not Game.dead:
		target_bob = clampf(hspeed / SPEED, 0.0, 1.5)
	bob_amt = lerpf(bob_amt, target_bob, 1.0 - exp(-delta * 8.0))
	bob_t += delta * hspeed * (1.7 if sprinting else 1.9)
	if on_floor and not was_on_floor:
		land_dip = 1.0
	was_on_floor = on_floor
	land_dip = lerpf(land_dip, 0.0, 1.0 - exp(-delta * 7.0))

	# --- sway: gun lags behind mouse look ---
	var md := mouse_delta
	mouse_delta = Vector2.ZERO
	var target_sway := Vector2(clampf(-md.x * 0.0012, -0.05, 0.05), clampf(md.y * 0.0012, -0.04, 0.04))
	if delta > 0.0:
		target_sway = target_sway / maxf(delta * 60.0, 1.0)
	sway = sway.lerp(target_sway, 1.0 - exp(-delta * 10.0))

	# --- compose offsets ---
	var pos := Vector3.ZERO
	var rot := Vector3.ZERO  # radians (x pitch, y yaw, z roll)
	if w == "bat":
		pos += Vector3(0.0, -0.14, 0.0)   # hold the bat lower on screen

	# bob figure-eight; sprint also tucks the gun down and rolls it
	var bk := 1.5 if sprinting else 1.0
	var bx := sin(bob_t) * 0.011 * bob_amt * bk
	var by := cos(bob_t * 2.0) * 0.006 * bob_amt * bk - 0.004 * bob_amt
	var bz := sin(bob_t * 2.0) * 0.004 * bob_amt * bk
	pos += Vector3(bx, by, bz)
	rot.z += sin(bob_t) * 0.012 * bob_amt * bk
	rot.x += cos(bob_t * 2.0) * 0.008 * bob_amt * bk
	rot.y += sin(bob_t) * 0.008 * bob_amt * bk
	if sprinting:
		var s := clampf((hspeed - SPEED) / (SPRINT_SPEED - SPEED), 0.0, 1.0)
		pos += Vector3(-0.03, -0.035, 0.02) * s
		rot += Vector3(deg_to_rad(-6), deg_to_rad(12), deg_to_rad(-6)) * s * (0.0 if recoil > 0.1 else 1.0)
	# idle breathing
	pos.y += sin(Time.get_ticks_msec() * 0.0017) * 0.0025
	pos.x += sin(Time.get_ticks_msec() * 0.0011) * 0.0015
	pos.y -= land_dip * 0.03

	# mouse sway
	pos += Vector3(sway.x, sway.y, 0.0)
	rot += Vector3(sway.y * 1.5, sway.x * 2.5, sway.x * 2.0)

	# recoil: kick back, muzzle climbs, slight random side twist
	pos.z += recoil * f.back
	pos.y += recoil * f.back * 0.18
	rot.x += recoil * f.rot
	rot.y += recoil * f.side * sin(Time.get_ticks_msec() * 0.05) * 6.0

	# draw / switch: gun swings up from below
	if draw_t < 1.0:
		var e := 1.0 - pow(1.0 - draw_t, 3.0)
		pos += Vector3(0.08, -0.4, 0.05) * (1.0 - e)
		rot.x += deg_to_rad(-55) * (1.0 - e)
		rot.z += deg_to_rad(20) * (1.0 - e)

	# bat swing: raise back, whip across and down, then settle
	if swing_t >= 0.0 and w == "bat":
		var k := swing_t / BAT_SWING_TIME
		var wind := smoothstep(0.0, 0.25, k)                    # 0..1 raising
		var strike := smoothstep(0.25, 0.5, k)                  # 0..1 whipping through
		var back := smoothstep(0.55, 1.0, k)                    # 0..1 returning
		pos += Vector3(0.1, 0.1, 0.05) * wind * (1.0 - strike)
		rot += Vector3(deg_to_rad(35), deg_to_rad(-25), deg_to_rad(-30)) * wind * (1.0 - strike)
		var follow := strike * (1.0 - back)
		pos += Vector3(-0.35, -0.12, -0.2) * follow
		rot += Vector3(deg_to_rad(-75), deg_to_rad(55), deg_to_rad(35)) * follow

	# reload
	if Game.reloading and not Game.dead:
		var p := clampf(1.0 - reload_left / reload_total, 0.0, 1.0)
		var r := _reload_pose(w, p)
		pos += r[0]
		rot += r[1]
	_animate_parts(w, f)

	gun.position = gun_pos + pos
	gun.rotation = rot

	# camera: recoil kick + strafe lean + landing nudge
	var strafe := Input.get_axis("move_left", "move_right") if not Game.dead else 0.0
	# walking / running animation: a gentle footstep bob (one soft dip per step), nothing else
	var moving := on_floor and not Game.dead and hspeed > 0.3
	step_amt = lerpf(step_amt, 1.0 if moving else 0.0, 1.0 - exp(-delta * 6.0))
	step_t = bob_t   # same stride phase as the gun bob, so they move together
	var bob := (0.010 if not sprinting else 0.017) * step_amt
	head.position.y = head_rest_y - sin(step_t) * sin(step_t) * bob - land_dip * 0.04
	head.position.x = sin(step_t) * 0.007 * step_amt
	camera.rotation.x = cam_kick - land_dip * 0.015
	camera.rotation.z = lerpf(camera.rotation.z, -strafe * 0.012 - sin(step_t) * 0.004 * step_amt, 1.0 - exp(-delta * 8.0))
	camera.fov = lerpf(camera.fov, base_fov + (5.0 if sprinting else 0.0), 1.0 - exp(-delta * 5.0))


# returns [position offset, rotation offset] for the reload at progress p (0..1)
func _reload_pose(w: String, p: float) -> Array:
	var pos := Vector3.ZERO
	var rot := Vector3.ZERO
	if w == "shotgun":
		# tilt gun up/side, then rock it with each shell pushed in
		var env := smoothstep(0.0, 0.12, p) * (1.0 - smoothstep(0.88, 1.0, p))
		var shells := sin(p * TAU * 3.0) * 0.5 + 0.5
		pos = Vector3(-0.05, -0.08, 0.04) * env + Vector3(0, 0.02, 0.02) * shells * env
		rot = Vector3(deg_to_rad(28), deg_to_rad(-8), deg_to_rad(-25)) * env
		rot.x += deg_to_rad(-4) * shells * env
		# cock the pump at the very end
		if p > 0.88:
			pos.z += sin((p - 0.88) / 0.12 * PI) * 0.04
		return [pos, rot]
	# pistol / smg / rifle: drop and roll, mag out, mag in with a bump, return
	var down := smoothstep(0.0, 0.18, p) * (1.0 - smoothstep(0.85, 1.0, p))
	pos = Vector3(-0.04, -0.12, 0.03) * down
	rot = Vector3(deg_to_rad(18), deg_to_rad(10), deg_to_rad(-32)) * down
	# slap the new mag in around 60%
	var slap := exp(-pow((p - 0.62) * 14.0, 2.0))
	pos.y += slap * 0.025
	rot.x += slap * deg_to_rad(-6)
	return [pos, rot]


func _animate_parts(w: String, f: Dictionary) -> void:
	# pistol slide / smg bolt-ish: moves back on the shot
	if part_rest.has("Slide"):
		var s := gun_model.find_child("Slide", true, false) as Node3D
		var back := slide_t
		if Game.reloading:
			back = maxf(back, 0.0)
		# slide locked back when the magazine is empty
		if Game.ammo[w] <= 0 and not Game.reloading:
			back = 1.0
		s.position = part_rest["Slide"] + Vector3(0, 0, 0.05 * back)
	if part_rest.has("Pump"):
		var pm := gun_model.find_child("Pump", true, false) as Node3D
		var k := 0.0
		if pump_t >= 0.0:
			k = sin(pump_t * PI)  # slide back and forward
		if Game.reloading:
			k = 0.0
		pm.position = part_rest["Pump"] + Vector3(0, 0, 0.1 * k)
	if part_rest.has("Mag"):
		var mg := gun_model.find_child("Mag", true, false) as Node3D
		var off := Vector3.ZERO
		if Game.reloading:
			var p := clampf(1.0 - reload_left / reload_total, 0.0, 1.0)
			# mag drops out 15-35%, new mag rises in 45-65%
			var out := smoothstep(0.15, 0.35, p) * (1.0 - smoothstep(0.45, 0.65, p))
			off = Vector3(0, -0.28, 0.0) * out
			mg.visible = out < 0.95
		else:
			mg.visible = true
		mg.position = part_rest["Mag"] + off
