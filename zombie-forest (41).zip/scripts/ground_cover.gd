@tool
extends Node3D
# Grows the grass when the scene starts (also in the editor, so you can see it).
# The blades are NOT saved in map.tscn - thousands of nodes would make the scene huge and slow.
# Change the density in art.gd -> QUALITY.grass_spacing (metres between clumps). The patch around the Campfire node stays bare.

const Art := preload("res://scripts/art.gd")

@export var arena := 58.0
@export var bare_radius := 5.0   # no grass this close to the campfire


func _ready() -> void:
	for c in get_children():
		c.queue_free()
	var center := Vector2.ZERO
	var camp := get_parent().get_node_or_null("Campfire") as Node3D if get_parent() else null
	if camp:
		center = Vector2(camp.position.x, camp.position.z)
	Art.build_ground_cover(self, arena, bare_radius, center)
