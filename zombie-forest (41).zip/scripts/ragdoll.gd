extends Node3D
# Physics ragdoll for a dead zombie.
#
# When a zombie dies, zombie.gd creates one of these. It takes the zombie's current pose, builds one
# RigidBody3D per body part (torso, head, 2 arms, 2 legs) joined with cone-twist joints, throws them
# according to PROFILES below, and every frame copies the bodies' positions back onto the zombie's
# skeleton, so the normal zombie model is what you see flopping around.
#
# THE THREE DEATHS: PROFILES["head"], ["chest"], ["leg"]. Each line says how hard one body part is
# thrown, in metres per second, for a normal pistol shot (power 1.0):
#   push      along the direction the bullet was travelling
#   up        straight up (negative = slammed down)
#   side      sideways, perpendicular to the bullet (the sign decides left/right)
#   fwd       along the way the zombie was facing (used by the leg shot to make it trip)
#   spin      rotation (rad/s) that tips the part's top away along the bullet direction
#   fwd_spin  rotation (rad/s) that tips the part's top forward, along the way the zombie faces
# Anything you leave out is 0. Change a number, press F5, shoot a zombie.

const PROFILES := {
	# head shot: the head snaps back hard, the body mostly just drops where it stands
	"head": {
		"Head":  {"push": 7.0, "up": 2.5, "spin": 12.0},
		"Torso": {"push": 1.5, "up": 0.5, "spin": 1.5},
		"ArmL":  {"push": 1.0, "up": 0.5},
		"ArmR":  {"push": 1.0, "up": 0.5},
		"LegL":  {"push": 0.3},
		"LegR":  {"push": 0.3},
	},
	# chest shot: the whole body is thrown backwards, arms flung out, then it lands flat on its back
	"chest": {
		"Torso": {"push": 9.0, "up": 2.5, "spin": 5.0},
		"Head":  {"push": 4.0, "up": 1.5, "spin": 6.0},
		"ArmL":  {"push": 9.5, "up": 1.5, "side": -2.5},
		"ArmR":  {"push": 9.5, "up": 1.5, "side": 2.5},
		"LegL":  {"push": 5.5, "up": 1.5},
		"LegR":  {"push": 5.5, "up": 1.5},
	},
	# leg shot: the legs are knocked out from under it and it trips, face first
	"leg": {
		"LegL":  {"push": 6.5, "up": 2.0, "side": -1.0},
		"LegR":  {"push": 6.5, "up": 1.0, "side": 1.0},
		"Torso": {"fwd": 2.8, "up": -0.5, "fwd_spin": 2.5},
		"Head":  {"fwd": 3.0, "up": -0.5, "fwd_spin": 3.0},
		"ArmL":  {"fwd": 4.5, "up": 0.5},
		"ArmR":  {"fwd": 4.5, "up": 0.5},
	},
}

# bone name -> collision box (in the bone's own space), mass, and which bone it hangs from + joint limits.
# Joint pivot = the bone origin + `pivot` (in bone space); `axis` is the direction the limb points.
const PARTS := {
	"Torso": {"size": Vector3(0.5, 0.75, 0.32), "off": Vector3(0, 0.4, 0), "mass": 12.0},
	"Head": {"size": Vector3(0.34, 0.34, 0.34), "off": Vector3.ZERO, "mass": 4.0,
		"parent": "Torso", "pivot": Vector3(0, -0.17, 0), "axis": Vector3(0, 1, 0), "swing": 55.0, "twist": 40.0},
	"ArmL": {"size": Vector3(0.15, 0.15, 0.78), "off": Vector3(0, 0, -0.4), "mass": 3.0,
		"parent": "Torso", "pivot": Vector3.ZERO, "axis": Vector3(0, 0, -1), "swing": 100.0, "twist": 30.0},
	"ArmR": {"size": Vector3(0.15, 0.15, 0.78), "off": Vector3(0, 0, -0.4), "mass": 3.0,
		"parent": "Torso", "pivot": Vector3.ZERO, "axis": Vector3(0, 0, -1), "swing": 100.0, "twist": 30.0},
	"LegL": {"size": Vector3(0.24, 0.84, 0.26), "off": Vector3(0, -0.42, 0), "mass": 7.0,
		"parent": "Torso", "pivot": Vector3.ZERO, "axis": Vector3(0, -1, 0), "swing": 55.0, "twist": 20.0},
	"LegR": {"size": Vector3(0.24, 0.84, 0.26), "off": Vector3(0, -0.42, 0), "mass": 7.0,
		"parent": "Torso", "pivot": Vector3.ZERO, "axis": Vector3(0, -1, 0), "swing": 55.0, "twist": 20.0},
}

const MAX_ACTIVE := 10       # oldest corpses vanish when more than this many exist
const LIFETIME := 6.0        # seconds a corpse lies there before it sinks into the ground
const SINK_TIME := 1.4       # seconds spent sinking
const WORLD_LAYER := 8       # ragdoll parts live on physics layer 4: they hit the ground/trees (layer 1)
							# but not the player, zombies, bullets or each other

static var active: Array = []

var zombie: Node3D
var skeleton: Skeleton3D
var bodies := {}             # bone index -> RigidBody3D
var rest_globals := {}       # bone index -> Transform3D (skeleton space) for bones without a body
var age := 0.0


# zone: "head" / "chest" / "leg"; dir: the way the bullet was travelling; power: 1.0 = one pistol shot
func start(z: Node3D, skel: Skeleton3D, zone: String, dir: Vector3, power: float, base_velocity: Vector3, body_scale: float) -> void:
	zombie = z
	skeleton = skel
	active = active.filter(func(r): return is_instance_valid(r))
	while active.size() >= MAX_ACTIVE:
		active.pop_front().finish()
	active.append(self)
	tree_exiting.connect(func(): active.erase(self))

	var count := skel.get_bone_count()
	var forward := -z.global_transform.basis.z
	forward.y = 0.0
	forward = forward.normalized()
	var shot := dir
	shot.y = clampf(shot.y, -0.3, 0.5)    # keep the throw mostly horizontal
	shot = shot.normalized()
	var side := shot.cross(Vector3.UP).normalized()
	var tip_axis := Vector3.UP.cross(shot)
	var fwd_tip_axis := Vector3.UP.cross(forward)
	var profile: Dictionary = PROFILES[zone]

	# 1. one rigid body per body part, starting exactly where the animated bone is right now
	for i in count:
		var bone_name := skel.get_bone_name(i)
		var g: Transform3D = skel.global_transform * skel.get_bone_global_pose(i)
		g.basis = g.basis.orthonormalized()
		if not PARTS.has(bone_name):
			rest_globals[i] = skel.get_bone_global_pose(i)
			continue
		var part: Dictionary = PARTS[bone_name]
		var rb := RigidBody3D.new()
		rb.name = bone_name
		rb.mass = part.mass * body_scale
		rb.linear_damp = 0.3
		rb.angular_damp = 3.0
		rb.collision_layer = WORLD_LAYER
		rb.collision_mask = 1
		rb.continuous_cd = true
		var pm := PhysicsMaterial.new()
		pm.friction = 1.0
		pm.bounce = 0.0
		rb.physics_material_override = pm
		var cs := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = (part.size as Vector3) * body_scale
		cs.shape = box
		cs.position = (part.off as Vector3) * body_scale
		rb.add_child(cs)
		add_child(rb)
		rb.global_transform = g
		bodies[i] = rb

		# 2. the throw: base velocity (so a running zombie keeps its momentum) + this zone's kick
		var p: Dictionary = profile.get(bone_name, {})
		var v := base_velocity
		v += shot * float(p.get("push", 0.0)) * power
		v += Vector3.UP * float(p.get("up", 0.0)) * power
		v += side * float(p.get("side", 0.0)) * power
		v += forward * float(p.get("fwd", 0.0)) * power
		rb.linear_velocity = v
		rb.angular_velocity = tip_axis * float(p.get("spin", 0.0)) * power \
			+ fwd_tip_axis * float(p.get("fwd_spin", 0.0)) * power

	# 3. joints (after every body is in the tree)
	for i in bodies:
		var part: Dictionary = PARTS[skel.get_bone_name(i)]
		if not part.has("parent"):
			continue
		var parent_i := skel.find_bone(part.parent)
		var child_rb: RigidBody3D = bodies[i]
		var axis_world: Vector3 = (child_rb.global_transform.basis * (part.axis as Vector3)).normalized()
		var helper := Vector3.UP if absf(axis_world.dot(Vector3.UP)) < 0.9 else Vector3.RIGHT
		var y_axis := axis_world.cross(helper).normalized()
		var z_axis := axis_world.cross(y_axis).normalized()
		var j := ConeTwistJoint3D.new()
		add_child(j)
		j.global_transform = Transform3D(Basis(axis_world, y_axis, z_axis),
			child_rb.global_transform * ((part.pivot as Vector3) * body_scale))
		j.node_a = bodies[parent_i].get_path()
		j.node_b = child_rb.get_path()
		j.set_param(ConeTwistJoint3D.PARAM_SWING_SPAN, deg_to_rad(part.swing))
		j.set_param(ConeTwistJoint3D.PARAM_TWIST_SPAN, deg_to_rad(part.twist))

	_sync_skeleton()


func _process(delta: float) -> void:
	age += delta
	if age > LIFETIME:
		var sink := delta * 0.9 / SINK_TIME * 1.0
		for rb in bodies.values():
			rb.freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
			rb.freeze = true
			rb.global_position.y -= sink
		if age > LIFETIME + SINK_TIME:
			finish()
			return
	_sync_skeleton()


# copy the physics bodies onto the zombie's bones so the model follows them
func _sync_skeleton() -> void:
	if not is_instance_valid(skeleton):
		return
	var inv := skeleton.global_transform.affine_inverse()
	var globals := {}
	for i in skeleton.get_bone_count():
		var g: Transform3D
		if bodies.has(i):
			var t: Transform3D = inv * (bodies[i] as RigidBody3D).global_transform
			g = Transform3D(t.basis.orthonormalized(), t.origin)
		else:
			g = rest_globals[i]
		globals[i] = g
		var parent := skeleton.get_bone_parent(i)
		var local: Transform3D = g if parent < 0 else (globals[parent] as Transform3D).affine_inverse() * g
		skeleton.set_bone_pose_position(i, local.origin)
		skeleton.set_bone_pose_rotation(i, local.basis.get_rotation_quaternion())


# remove the corpse (and the zombie node that owns the model)
func finish() -> void:
	active.erase(self)
	if is_instance_valid(zombie):
		zombie.queue_free()
	queue_free()
