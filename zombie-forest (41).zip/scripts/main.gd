extends Node3D
# Runs the wave spawner. The map is the "World" node in main.tscn, an instance of scenes/map.tscn
# (open that scene to move trees etc.). If the World node is ever missing, it is built from code instead.

const World := preload("res://scripts/world.gd")
const Art := preload("res://scripts/art.gd")
const ZOMBIE := preload("res://scenes/zombie.tscn")
const ARENA := 58.0          # playable area is +-ARENA on x and z
const TREE_COUNT := 260
const MAX_ALIVE := 25

var to_spawn := 0
var spawn_timer := 0.0
var intermission := 5.0
var wave_active := false
var fire_light: OmniLight3D

@onready var player: Node3D = $Player


func _ready() -> void:
	var world := get_node_or_null("World")
	if world == null:
		world = World.build(self, ARENA, TREE_COUNT)
	fire_light = world.find_child("FireLight", true, false)
	_upgrade_graphics(world)
	add_child(Art.build_soft_filter())
	Game.message.emit("Survive the forest!  B = shop")


func _process(delta: float) -> void:
	if fire_light:
		fire_light.light_energy = 2.2 + randf() * 0.8   # campfire flicker
	if Game.dead:
		return
	var alive := get_tree().get_nodes_in_group("zombies").size()
	if to_spawn > 0:
		spawn_timer -= delta
		if spawn_timer <= 0.0 and alive < MAX_ALIVE:
			_spawn_zombie()
			to_spawn -= 1
			spawn_timer = maxf(0.35, 1.3 - Game.wave * 0.07)
	elif alive == 0:
		if wave_active:
			wave_active = false
			var bonus := 50 + Game.wave * 25
			Game.add_money(bonus)
			Game.heal(30.0)
			Game.message.emit("Wave %d cleared!  +$%d   B = shop" % [Game.wave, bonus])
			intermission = 10.0
		else:
			intermission -= delta
			if intermission <= 0.0:
				_start_wave()


func _start_wave() -> void:
	Game.wave += 1
	to_spawn = 4 + Game.wave * 3
	wave_active = true
	spawn_timer = 0.0
	Game.message.emit("Wave %d" % Game.wave)
	Game.changed.emit()


func _spawn_zombie() -> void:
	var a := randf() * TAU
	var d := randf_range(24.0, 34.0)
	var p := player.global_position + Vector3(cos(a), 0.0, sin(a)) * d
	p.x = clampf(p.x, -ARENA, ARENA)
	p.z = clampf(p.z, -ARENA, ARENA)
	p.y = 0.5
	var kind := "normal"
	var r := randf()
	if Game.wave >= 4 and r < 0.12:
		kind = "tank"
	elif Game.wave >= 2 and r < 0.35:
		kind = "runner"
	var z := ZOMBIE.instantiate()
	z.setup(Game.wave, kind)
	add_child(z)
	z.global_position = p


# Applies the newer look (starry sky, ACES tonemapping, softer shadows, vignette) to the saved map,
# whose old environment is stored inside map.tscn.
func _upgrade_graphics(world: Node) -> void:
	var we := world.get_node_or_null("WorldEnvironment") as WorldEnvironment
	if we:
		we.environment = Art.environment()
	_refresh_particles(world)
	var moon := world.get_node_or_null("Moon") as DirectionalLight3D
	if moon:
		moon.light_energy = 0.1
		moon.shadow_enabled = true
		moon.shadow_blur = 1.5
		moon.shadow_bias = 0.03
		moon.directional_shadow_max_distance = 60.0
	var fl := player.get_node_or_null("Head/Camera3D/Flashlight") as SpotLight3D
	if fl:
		fl.shadow_blur = 1.5
		fl.spot_attenuation = 0.8
		fl.light_energy = 6.0
	# dark vignette around the screen edges
	var layer := CanvasLayer.new()
	layer.layer = -1
	var rect := ColorRect.new()
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = "shader_type canvas_item;\nvoid fragment() {\n\tvec2 uv = UV - 0.5;\n\tfloat v = smoothstep(0.3, 0.85, length(uv * vec2(1.0, 0.9)));\n\tCOLOR = vec4(0.0, 0.0, 0.0, v * 0.6);\n}\n"
	var sm := ShaderMaterial.new()
	sm.shader = sh
	rect.material = sm
	layer.add_child(rect)
	add_child(layer)


# The saved map has its own copies of the fire / ember particles baked in, so swap them
# for the current (rounder, dimmer) versions from art.gd.
func _refresh_particles(world: Node) -> void:
	var camp := world.get_node_or_null("Campfire") as Node3D
	if camp:
		for pair in [["Flames", Art.flame_particles()], ["Embers", Art.ember_particles()]]:
			var old := camp.get_node_or_null(pair[0]) as Node3D
			var fresh := pair[1] as Node3D
			if old:
				fresh.position = old.position
				old.free()
			fresh.name = pair[0]
			camp.add_child(fresh)
		var bed := camp.get_node_or_null("EmberBed") as MeshInstance3D
		if bed:
			bed.material_override = Art.glow_mat(Color(1.0, 0.4, 0.08), 1.2)
	# no floating fireflies any more: drop them if an old saved map still has them
	var old_ff := world.get_node_or_null("Fireflies")
	if old_ff:
		old_ff.free()
