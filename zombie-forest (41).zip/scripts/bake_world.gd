@tool
extends EditorScript
# Re-creates scenes/map.tscn from scratch: a brand-new random forest, rocks, mushrooms, campfire...
#
# You normally DON'T need this. map.tscn already exists: just open it and move things around.
# Only run this if you want to throw the map away and start over (hand edits are lost!).
#   Open this file in the Script editor, then menu  File > Run   (Ctrl+Shift+X).

const World := preload("res://scripts/world.gd")


func _run() -> void:
	var main_script: Script = load("res://scripts/main.gd")
	var main_consts: Dictionary = main_script.get_script_constant_map()
	var err := World.save_map("res://scenes/map.tscn", main_consts.get("ARENA", 58.0), main_consts.get("TREE_COUNT", 260))
	if err == OK:
		print("bake_world: scenes/map.tscn rebuilt. If it is open in the editor, reload it (Scene > Reload Saved Scene).")
	else:
		push_error("bake_world: could not save map.tscn (error %d)" % err)
