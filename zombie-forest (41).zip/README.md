# Zombie Forest (Godot 4.3+)

Open `project.godot` in Godot and press F5.

## Controls
WASD move, Shift sprint, Space jump, mouse look, Left click shoot (hold for auto guns),
R reload, walk over loot to pick it up, F flashlight, 1-4 switch weapon, **E at the cabin window = shop**, Esc menu (mouse sensitivity, restart) (pauses the game), Esc free the mouse.

## How it works
- Dark foggy forest with a campfire clearing. Waves of zombies spawn around you and chase you.
- Kill zombies for money, clear a wave for a bonus + a bit of healing.
- Shop: buy SMG / Shotgun / Rifle, upgrade damage, fire rate, magazine, reload speed (5 levels each), buy medkits.
- Die -> press Enter to restart.

## Files
- `scripts/game.gd`   autoload: money, health, weapon stats + upgrade math (edit WEAPONS to add guns)
- `scripts/main.gd`   forest generation + wave spawner (edit TREE_COUNT, wave sizes)
- `scripts/player.gd` movement, shooting, reloading
- `scenes/zombie.tscn` just the collision capsule + an empty Visual node; the body is `assets/models/zombie.gltf`
- `scripts/zombie.gd` per-zombie colors, chase AI, stats per wave/kind (normal / runner / tank), hit zones + knockback
- `scripts/ragdoll.gd` the physics ragdoll a zombie turns into when it dies (the 3 death throws live at the top)
- `scripts/hud.gd`    HUD, shop UI, game over screen
- `scripts/art.gd`    **all visuals**: palette, quality knobs, environment, trees, campfire, gun models, particles, UI theme

## Upgrading the graphics
Everything visual goes through `scripts/art.gd`; gameplay scripts only ask it for things.

- **Restyle fast:** edit the `PALETTE` and `QUALITY` blocks at the top of `art.gd` (turn off `moon_shadows`/`glow` or raise `grass_spacing` if it runs slowly).
- **Drop in real assets, no code changes** (picked up automatically if the file exists):
  - `assets/models/zombie.glb` (or `zombie_normal` / `zombie_runner` / `zombie_tank`, `.glb` `.gltf` `.tscn`; feet at y=0, facing -Z)
  - `assets/models/gun_pistol.glb`, `gun_smg`, `gun_shotgun`, `gun_rifle` (barrel toward -Z)
  - `assets/textures/ground.png`, `bark.png`, `foliage.png` (tileable)
  - `assets/fonts/main.ttf` (UI font)
- **Replace one thing:** rewrite a single `build_*` function in `art.gd` (e.g. `build_trees`); callers only use its return value.

## Hit zones, knockback & ragdolls
Where you hit a zombie decides what happens. The zone comes from the height of the bullet hit: below `LEG_HEIGHT` = **leg**, above `HEAD_HEIGHT` = **head**, in between = **chest** (arms count as chest).

| zone | zombie survives the shot | zombie dies |
|---|---|---|
| head | short stagger (stops for 0.3 s) + small shove | head snaps back, body crumples close by |
| chest | big shove backwards | thrown backwards, arms flung out, lands flat |
| leg | limps for 1.4 s at 45% speed | legs swept out from under it, it trips and face-plants forward |

- Heavier shots throw harder (rifle > pistol > SMG), a shotgun blast counts as one big hit, and tanks are harder to move.
- A running zombie keeps its momentum when it dies.
- **Tune it:** the numbers for surviving hits are `KNOCKBACK`, `STUN`, `LIMP_TIME`, `LIMP_SPEED` at the top of `zombie.gd`. The three death throws are the `PROFILES` table at the top of `ragdoll.gd` (every line says how hard one body part is thrown, with a comment explaining the keys). Change a number, press F5, shoot a zombie.
- Corpses lie around for 6 s, then sink into the ground. At most 10 exist at once (`MAX_ACTIVE`, `LIFETIME` in `ragdoll.gd`). Bullets and the player pass through corpses.
- `RAGDOLL := false` in `zombie.gd` turns ragdolls off and brings back the old death animation.

## Loot & headshots
- Normal zombies in waves 1-3 die to one headshot (`HEADSHOT_KILL_WAVES` in `zombie.gd`); later zombies take 2.5x damage on headshots.
- Zombies drop money (and sometimes ammo) that you must walk over to collect. Ammo goes into spare rounds (HUD shows `mag / spare`); reloads use spare rounds.
- Drops are in `scripts/loot.gd`, their look is `Art.build_loot()` (or `assets/models/loot_money` / `loot_ammo`).

## Skinned zombie model
- `assets/models/zombie.gltf` is the zombie as ONE mesh with a bone skeleton (Root, LegL/R, Torso, Head, ArmL/R) and animations walk / idle / attack / death. `zombie.gd` uses it automatically. Open the project in the Godot editor once so it gets imported.
- Rebuild it with `python3 tools/make_zombie_gltf.py` (edit BOXES / BONES / the animation functions), or import the .gltf into Blender to sculpt and animate it there, then export over it.

## Editing the map (move trees, rocks, the campfire...)
The whole map is a normal scene: **`scenes/map.tscn`**. Open it in the Godot editor (double-click it in the FileSystem dock).

- Click a tree in the 3D view (or pick it in the Scene dock under `Trees`) and drag the arrows to move it. `W` = move tool, `E` = rotate, `R` = scale. Hold Ctrl while dragging to snap.
- `Ctrl+D` duplicates the selected tree, `Delete` removes it. Press `Ctrl+S` to save, then F5 to play (the game starts from `main.tscn`, which just contains this map).
- To add a tree: drag `scenes/tree.tscn` (or `dead_tree.tscn`, `rock.tscn`, `mushroom.tscn`) from the FileSystem dock into the Scene dock onto the `Trees` / `Rocks` / `Mushrooms` node.
- Groups in the Scene dock: `Trees`, `Rocks`, `Mushrooms`, `Campfire` (the dirt patch, stones, flames and light move together), `Ground`, `Moon`, `WorldEnvironment` (sky/fog/glow, editable in the Inspector).
- The player start is the `Player` node in `main.tscn`. Trees have collision built in, so a moved tree blocks you in its new spot.
- Grass is the one thing you can't click: it is grown by the `GroundCover` node when the scene starts (density: `QUALITY.grass_spacing` in `art.gd`; one jittered clump per grid cell so the whole ground is covered evenly, far-away chunks hide themselves).
- Trees farther than 75 units from the camera are hidden on purpose (the fog hides them in game anyway). If trees vanish when you zoom the editor camera way out, that is why: fly closer.
- Want a brand new random forest instead? Open `scripts/bake_world.gd` and use File > Run (Ctrl+Shift+X). That overwrites `map.tscn`, so your hand edits are lost.

## Prefabs (shared resources)
Trees, dead trees, rocks and mushrooms are scenes (`scenes/tree.tscn`, `dead_tree.tscn`, `rock.tscn`, `mushroom.tscn`) built from shared meshes (`assets/meshes`) and materials (`assets/materials`), so every copy reuses the same data. Edit those files (e.g. recolor `needles_0..3.tres`, swap `bark.tres` texture) and the whole forest changes. The tree collision is inside the tree prefab. Grass stays one MultiMesh. Regenerate these files with `python3 tools/make_prefabs.py` (you do NOT need to re-run `bake_world.gd` for that; the map only points at the prefab scenes).
