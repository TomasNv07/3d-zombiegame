#!/usr/bin/env python3
"""Writes the shared forest resources and prefab scenes (pure standard library):

  assets/materials/*.tres   ground, dirt, bark, needles (4 shades), stone, mushroom cap/stem
                            (they use the PNGs in assets/textures, made by tools/make_textures.py)
  assets/meshes/*.tres      trunk, branch, 7 foliage cones, rock, mushroom cap/stem
  scenes/tree.tscn          pine tree: trunk + 7 foliage tiers + trunk collision
  scenes/dead_tree.tscn     bare tree: trunk + 3 branches + collision
  scenes/rock.tscn, scenes/mushroom.tscn

Every instance of a prefab shares the same meshes/materials/textures, so the map costs
almost no extra memory. Edit the numbers below (or the files in the Godot editor) and re-run.
"""
import math, os
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
def w(path, text):
    p = os.path.join(ROOT, path); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w").write(text)
def col(c): return "Color(%g, %g, %g, 1)" % tuple(c)
def flat(c): return "%g, %g, %g, 1" % tuple(c)   # PackedColorArray wants plain floats, NOT Color(...)
def mul(c, f): return tuple(x * f for x in c)

# ------------------------------------------------------------------ materials
def std_mat(color, rough, tex=None, scale=None, normal=None, normal_scale=1.0):
    """StandardMaterial3D with a PNG albedo (+ optional PNG normal map), triplanar mapped."""
    ext, n = "", 0
    if tex:
        n += 1
        ext += f'[ext_resource type="Texture2D" path="res://assets/textures/{tex}.png" id="{n}"]\n'
        tex_id = n
    if normal:
        n += 1
        ext += f'[ext_resource type="Texture2D" path="res://assets/textures/{normal}.png" id="{n}"]\n'
        nrm_id = n
    s = f'[gd_resource type="StandardMaterial3D" load_steps={n + 1} format=3]\n\n{ext}\n[resource]\n'
    s += f"albedo_color = {col(color)}\n"
    if tex:
        s += f'albedo_texture = ExtResource("{tex_id}")\n'
    if normal:
        s += f'normal_enabled = true\nnormal_scale = {normal_scale}\nnormal_texture = ExtResource("{nrm_id}")\n'
    if tex:
        s += 'uv1_scale = Vector3(%g, %g, %g)\nuv1_triplanar = true\n' % (scale, scale, scale)
    s += f"roughness = {rough}\n"
    return s
# the textures carry the real colours now, so albedo_color is just a brightness tint (white = unchanged)
WHITE = (1, 1, 1)
w("assets/materials/ground.tres", std_mat(WHITE, 1.0, "ground", 0.2, "ground_n", 1.0))
w("assets/materials/dirt.tres", std_mat(WHITE, 1.0, "dirt", 0.35, "dirt_n", 0.8))
w("assets/materials/bark.tres", std_mat(WHITE, 1.0, "bark", 1.1, "bark_n", 1.3))
for i in range(4):
    t = 0.8 + i * 0.1                                   # each foliage tier slightly lighter than the one below
    w(f"assets/materials/needles_{i}.tres", std_mat((t, t, t), 0.95, "needles", 0.9, "needles_n", 1.0))
w("assets/materials/stone.tres", std_mat(WHITE, 0.95, "stone", 0.8, "stone_n", 1.0))
w("assets/materials/mushroom_cap.tres", '''[gd_resource type="StandardMaterial3D" format=3]

[resource]
shading_mode = 0
albedo_color = Color(0.25, 0.95, 0.85, 1)
emission_enabled = true
emission = Color(0.25, 0.95, 0.85, 1)
emission_energy_multiplier = 0.8
''')
w("assets/materials/mushroom_stem.tres", std_mat((0.7, 0.75, 0.7), 0.9))

# ------------------------------------------------------------------ meshes
def cyl_mesh(top, bottom, h, seg, name):
    w(f"assets/meshes/{name}.tres", f'''[gd_resource type="CylinderMesh" format=3]

[resource]
top_radius = {top}
bottom_radius = {bottom}
height = {h}
radial_segments = {seg}
rings = 1
''')
cyl_mesh(0.06, 0.15, 9.4, 8, "trunk")   # thin and tall
cyl_mesh(0.015, 0.05, 1.8, 5, "branch")
# radius, height, center y: 7 overlapping tiers, the lowest starts ~0.9 m above the ground like a pine
TIERS = [(1.7, 2.2, 2.0), (1.5, 2.1, 3.1), (1.3, 2.0, 4.2), (1.1, 1.9, 5.3), (0.9, 1.8, 6.4), (0.65, 1.7, 7.5), (0.4, 1.6, 8.6)]
for i, (r, h, y) in enumerate(TIERS):
    cyl_mesh(0.0, r, h, 10, f"cone_{i}")
cyl_mesh(0.025, 0.035, 0.14, 5, "mushroom_stem")
w("assets/meshes/rock.tres", '''[gd_resource type="SphereMesh" format=3]

[resource]
radius = 0.5
height = 0.8
radial_segments = 7
rings = 4
''')
w("assets/meshes/mushroom_cap.tres", '''[gd_resource type="SphereMesh" format=3]

[resource]
radius = 0.14
height = 0.14
radial_segments = 8
rings = 3
is_hemisphere = true
''')

# ------------------------------------------------------------------ scenes
class Scene:
    def __init__(self): self.ext = {}; self.sub = []; self.nodes = []
    def res(self, rtype, path):
        if path not in self.ext: self.ext[path] = (len(self.ext) + 1, rtype)
        return 'ExtResource("%d")' % self.ext[path][0]
    def node(self, text): self.nodes.append(text)
    def write(self, path):
        head = '[gd_scene load_steps=%d format=3]\n\n' % (len(self.ext) + len(self.sub) + 1)
        for p, (i, t) in self.ext.items():
            head += '[ext_resource type="%s" path="%s" id="%d"]\n' % (t, p, i)
        head += "\n" + "".join(s + "\n" for s in self.sub)
        w(path, head + "\n".join(self.nodes))

def xf(R, o):  # row-major rotation matrix + origin
    return "Transform3D(%s, %g, %g, %g)" % (", ".join("%g" % R[i][j] for i in range(3) for j in range(3)), *o)
def mm(a, b): return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def roty(t): c, s = math.cos(t), math.sin(t); return [[c, 0, s], [0, 1, 0], [-s, 0, c]]
def rotz(t): c, s = math.cos(t), math.sin(t); return [[c, -s, 0], [s, c, 0], [0, 0, 1]]
I3 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
VIS = "visibility_range_end = 75.0\n"   # far trees are hidden anyway by the fog

def mesh_node(sc, name, parent, mesh, mat, pos=None, R=None, vis=True, shadow=True):
    s = f'[node name="{name}" type="MeshInstance3D" parent="{parent}"]\n'
    if R is not None or pos is not None:
        s += "transform = %s\n" % xf(R or I3, pos or (0, 0, 0))
    s += "mesh = %s\n" % sc.res("Mesh", f"res://assets/meshes/{mesh}.tres")
    s += "surface_material_override/0 = null\n" if False else ""
    s += "material_override = %s\n" % sc.res("Material", f"res://assets/materials/{mat}.tres")
    if vis: s += VIS
    if not shadow: s += "cast_shadow = 0\n"
    sc.node(s)

def collision(sc):
    sc.sub.append('[sub_resource type="CylinderShape3D" id="TrunkShape"]\nradius = 0.22\nheight = 9.0\n')
    sc.node('[node name="CollisionShape3D" type="CollisionShape3D" parent="."]\ntransform = %s\nshape = SubResource("TrunkShape")\n' % xf(I3, (0, 4.5, 0)))

# pine
sc = Scene()
sc.node('[node name="Tree" type="StaticBody3D"]\n')
collision(sc)
mesh_node(sc, "Trunk", ".", "trunk", "bark", (0, 4.7, 0))
for i, (r, h, y) in enumerate(TIERS):
    mesh_node(sc, f"Foliage{i + 1}", ".", f"cone_{i}", f"needles_{i % 4}", (0, y, 0))
sc.write("scenes/tree.tscn")

# dead tree
sc = Scene()
sc.node('[node name="DeadTree" type="StaticBody3D"]\n')
collision(sc)
mesh_node(sc, "Trunk", ".", "trunk", "bark", (0, 4.7, 0))
for k in range(3):
    tilt = 0.9 * (1 if k % 2 == 0 else -1)
    R = mm(roty(k * 2.1), rotz(tilt))
    yv = (R[0][1], R[1][1], R[2][1])  # basis y axis
    at = (yv[0] * 0.9, 3.4 + k * 0.7 + yv[1] * 0.9, yv[2] * 0.9)
    mesh_node(sc, f"Branch{k + 1}", ".", "branch", "bark", at, R)
sc.write("scenes/dead_tree.tscn")

# rock (visual only)
sc = Scene()
sc.node('[node name="Rock" type="Node3D"]\n')
mesh_node(sc, "Mesh", ".", "rock", "stone", vis=True)
sc.write("scenes/rock.tscn")

# glowing mushroom
sc = Scene()
sc.node('[node name="Mushroom" type="Node3D"]\n')
mesh_node(sc, "Cap", ".", "mushroom_cap", "mushroom_cap", (0, 0.14, 0), shadow=False)
mesh_node(sc, "Stem", ".", "mushroom_stem", "mushroom_stem", (0, 0.07, 0), shadow=False)
sc.write("scenes/mushroom.tscn")
print("prefabs written")
