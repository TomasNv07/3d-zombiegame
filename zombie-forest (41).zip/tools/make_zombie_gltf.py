#!/usr/bin/env python3
"""Builds assets/models/zombie.gltf: the zombie as ONE skinned mesh with a bone skeleton
and 4 animations (walk, idle, attack, death). Pure standard library.

    python3 tools/make_zombie_gltf.py

Open assets/models/zombie.gltf in Godot (it auto-imports). zombie.gd picks it up
automatically and plays the animations. Edit BOXES / BONES below to change the shape, or
import the .gltf into Blender to keep working on it there.
"""
import base64, json, math, struct, os

# ---------------------------------------------------------------- skeleton
# name, parent index, local position, rest rotation about X (radians)
BONES = [
    ("Root",  -1, (0, 0, 0),         0.0),
    ("LegL",   0, (-0.15, 0.85, 0),  0.0),
    ("LegR",   0, (0.15, 0.85, 0),   0.0),
    ("Torso",  0, (0, 0.85, 0),     -0.18),
    ("Head",   3, (0, 0.99, -0.03),  0.1),
    ("ArmL",   3, (-0.4, 0.68, 0),   0.18),
    ("ArmR",   3, (0.4, 0.68, 0),    0.18),
]
B = {b[0]: i for i, b in enumerate(BONES)}

# ---------------------------------------------------------------- materials
MATS = {
    "Skin":     dict(color=(0.46, 0.5, 0.4), rough=0.55),
    "SkinDark": dict(color=(0.27, 0.3, 0.24), rough=0.7),
    "Shirt":    dict(color=(0.22, 0.18, 0.16), rough=0.98),
    "Pants":    dict(color=(0.1, 0.1, 0.14), rough=0.98),
    "Boots":    dict(color=(0.06, 0.05, 0.05), rough=0.8),
    "Hair":     dict(color=(0.05, 0.04, 0.03), rough=1.0),
    "Wound":    dict(color=(0.3, 0.03, 0.03), rough=0.25),
    "Socket":   dict(color=(0.015, 0.0, 0.0), rough=1.0),
    "Eye":      dict(color=(0.9, 0.2, 0.08), rough=1.0, emissive=(0.9, 0.2, 0.08), strength=1.6),
    "Metal":    dict(color=(0.14, 0.14, 0.17), rough=0.4, metal=0.8),
    "Bone":     dict(color=(0.68, 0.64, 0.52), rough=0.6),
    "Teeth":    dict(color=(0.6, 0.55, 0.38), rough=0.5),
    "Rag":      dict(color=(0.1, 0.09, 0.08), rough=1.0),
    "Blood":    dict(color=(0.14, 0.015, 0.015), rough=0.3),
}

# ---------------------------------------------------------------- boxes
# mesh, bone, material, size, position (in bone space), rotation about X (degrees)
BOXES = []
def box(mesh, bone, mat, size, pos, rotx=0.0):
    BOXES.append((mesh, bone, mat, size, pos, rotx))

# --- legs: thighs, knees, shins, torn trousers, boots with soles
for i, leg in enumerate(("LegL", "LegR")):
    sx = -1 if i == 0 else 1
    box("Body", leg, "Pants", (0.22, 0.5, 0.24), (0, -0.25, 0))
    box("Body", leg, "Pants", (0.24, 0.1, 0.26), (0, -0.5, 0))          # knee
    box("Body", leg, "Pants", (0.19, 0.32, 0.22), (0, -0.68, 0))
    box("Body", leg, "Rag", (0.25, 0.05, 0.27), (0, -0.55, 0.0))          # frayed hem
    box("Body", leg, "Boots", (0.24, 0.12, 0.34), (0, -0.8, -0.05))
    box("Body", leg, "Boots", (0.25, 0.03, 0.36), (0, -0.865, -0.05))     # sole
    box("Body", leg, "Boots", (0.2, 0.1, 0.1), (0, -0.74, 0.07))          # boot top
# torn trouser leg showing flesh, bone on one shin
box("Body", "LegL", "Wound", (0.1, 0.16, 0.02), (0.02, -0.4, -0.125))
box("Body", "LegL", "SkinDark", (0.18, 0.12, 0.2), (0, -0.68, -0.01))
box("Body", "LegR", "Bone", (0.05, 0.14, 0.03), (-0.03, -0.66, -0.115))
box("Body", "LegR", "Wound", (0.12, 0.17, 0.02), (-0.03, -0.66, -0.112))

# --- torso: hips, belt, torn shirt, ribs, spine hump
box("Body", "Torso", "Pants", (0.44, 0.2, 0.26), (0, 0.1, 0))
box("Body", "Torso", "Boots", (0.46, 0.04, 0.28), (0, 0.2, 0))            # belt
box("Body", "Torso", "Shirt", (0.52, 0.44, 0.3), (0, 0.45, 0))            # chest
box("Body", "Torso", "Shirt", (0.56, 0.16, 0.32), (0, 0.66, 0))           # shoulders
box("Body", "Torso", "Shirt", (0.3, 0.2, 0.2), (0, 0.72, 0.13), -25)      # hunched upper back
box("Body", "Torso", "Skin", (0.12, 0.12, 0.12), (0, 0.8, -0.01))         # neck
box("Body", "Torso", "SkinDark", (0.04, 0.12, 0.04), (0.05, 0.8, -0.05), 10)  # neck tendon
box("Body", "Torso", "Skin", (0.14, 0.05, 0.12), (-0.18, 0.74, -0.03))    # collar bone
box("Body", "Torso", "Skin", (0.14, 0.05, 0.12), (0.18, 0.74, -0.03))
# big torn open belly: wound, exposed ribs, dark inside
box("Body", "Torso", "Wound", (0.24, 0.22, 0.02), (0.1, 0.42, -0.155))
box("Body", "Torso", "Blood", (0.16, 0.16, 0.02), (0.1, 0.42, -0.165))
for k in range(4):
    box("Body", "Torso", "Bone", (0.2, 0.025, 0.03), (0.1, 0.34 + k * 0.05, -0.175), 6 if k % 2 else -6)
# dried blood down the shirt
box("Body", "Torso", "Blood", (0.06, 0.3, 0.02), (-0.13, 0.5, -0.156))
box("Body", "Torso", "Blood", (0.1, 0.12, 0.02), (-0.18, 0.62, -0.157))
# ragged shirt hem (uneven strips of different length) + a torn flap
for i, h in enumerate((0.1, 0.22, 0.14, 0.3, 0.12, 0.2)):
    box("Body", "Torso", "Shirt", (0.075, h, 0.02), (-0.2 + i * 0.08, 0.23 - h / 2 + 0.04, -0.152))
    box("Body", "Torso", "Shirt", (0.075, h * 0.8, 0.02), (-0.2 + i * 0.08, 0.2 - h * 0.4 + 0.04, 0.152))
box("Body", "Torso", "Rag", (0.14, 0.16, 0.03), (-0.26, 0.5, -0.1), 0)

# --- head: narrower skull, sunken cheeks, nose, ears, dropped jaw with teeth
box("Body", "Head", "Skin", (0.28, 0.3, 0.3), (0, 0.02, 0))                    # skull
box("Body", "Head", "Skin", (0.3, 0.1, 0.26), (0, 0.15, 0.0))                  # brow/crown
box("Body", "Head", "SkinDark", (0.07, 0.1, 0.04), (-0.1, -0.07, -0.14), 8)    # sunken cheeks
box("Body", "Head", "SkinDark", (0.07, 0.1, 0.04), (0.1, -0.07, -0.14), 8)
box("Body", "Head", "Skin", (0.05, 0.09, 0.06), (0, -0.04, -0.16), -10)        # nose
box("Body", "Head", "Skin", (0.03, 0.08, 0.05), (-0.155, 0.0, 0.0))            # ears
box("Body", "Head", "Skin", (0.03, 0.08, 0.05), (0.155, 0.0, 0.0))
box("Body", "Head", "Skin", (0.24, 0.07, 0.24), (0, -0.14, -0.03), 22)         # jaw, hanging open
box("Body", "Head", "Socket", (0.17, 0.06, 0.03), (0, -0.115, -0.15), 12)      # open mouth
box("Body", "Head", "Teeth", (0.14, 0.02, 0.02), (0, -0.095, -0.158), 12)      # upper teeth
box("Body", "Head", "Teeth", (0.12, 0.02, 0.02), (0, -0.16, -0.14), 22)        # lower teeth
box("Body", "Head", "Wound", (0.08, 0.1, 0.02), (-0.09, -0.12, -0.152), 10)    # torn cheek
box("Body", "Head", "Blood", (0.05, 0.14, 0.02), (0.04, -0.2, -0.13), 10)      # blood from mouth
for s_ in (-1, 1):
    box("Body", "Head", "Socket", (0.09, 0.075, 0.02), (0.075 * s_, 0.045, -0.151))   # deep eye sockets
    box("Body", "Head", "Eye", (0.03, 0.03, 0.02), (0.075 * s_, 0.04, -0.16))          # small cold glint
    box("Body", "Head", "SkinDark", (0.1, 0.02, 0.02), (0.075 * s_, 0.09, -0.153), -6 * s_)  # heavy brow
# patchy hair clumps
box("Hair", "Head", "Hair", (0.3, 0.05, 0.2), (0, 0.19, 0.07))
box("Hair", "Head", "Hair", (0.06, 0.16, 0.08), (-0.14, 0.08, 0.08))
box("Hair", "Head", "Hair", (0.08, 0.1, 0.06), (0.1, 0.1, 0.14))
box("Hair", "Head", "Hair", (0.2, 0.14, 0.04), (0, 0.06, 0.16))
box("Hair", "Head", "Hair", (0.05, 0.08, 0.05), (0.12, 0.2, -0.05))

# --- arms: torn sleeve, bare forearm with wounds, hand with 4 fingers + thumb
for i, arm in enumerate(("ArmL", "ArmR")):
    sx = -1 if i == 0 else 1
    box("Body", arm, "Shirt", (0.15, 0.15, 0.3), (0, 0, -0.17))
    box("Body", arm, "Rag", (0.17, 0.17, 0.05), (0, 0, -0.33))                    # frayed sleeve end
    box("Body", arm, "Skin", (0.1, 0.1, 0.17), (0, -0.02, -0.46))                  # upper forearm
    box("Body", arm, "Skin", (0.095, 0.095, 0.2), (0, -0.04, -0.63), 2)           # wrist (slightly bent)
    box("Body", arm, "SkinDark", (0.04, 0.03, 0.2), (0.03 * sx, 0.03, -0.52))     # veins/bruise
    box("Body", arm, "SkinDark", (0.1, 0.09, 0.1), (0, -0.05, -0.76))             # palm, grey with grime
    for f, fx in enumerate((-0.036, -0.012, 0.012, 0.036)):
        L = (0.09, 0.11, 0.1, 0.075)[f]
        box("Body", arm, "SkinDark", (0.018, 0.02, L), (fx, -0.055, -0.81 - L / 2 + 0.04), 4 * (f - 1.5))
    box("Body", arm, "SkinDark", (0.02, 0.02, 0.07), (0.06 * sx, -0.05, -0.78), 0)  # thumb
    box("Body", arm, "Blood", (0.1, 0.05, 0.08), (0, -0.04, -0.83))              # bloody fingertips
box("Body", "ArmL", "Wound", (0.08, 0.02, 0.12), (0.0, 0.03, -0.5))
box("Body", "ArmR", "Bone", (0.03, 0.03, 0.1), (0.0, 0.03, -0.6))                 # bone showing
box("Body", "ArmR", "Wound", (0.07, 0.02, 0.16), (0.0, 0.03, -0.6))

for s_ in (-1, 1):
    box("TankPlates", "Torso", "Metal", (0.3, 0.12, 0.38), (0.42 * s_, 0.8, 0))
box("TankPlates", "Torso", "Metal", (0.5, 0.4, 0.04), (0, 0.45, -0.19))

# ---------------------------------------------------------------- tiny matrix helpers (rigid transforms)
def rotx(a):
    c, s = math.cos(a), math.sin(a)
    return [[1, 0, 0], [0, c, -s], [0, s, c]]
def mmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def mv(m, v):
    return [sum(m[i][k] * v[k] for k in range(3)) for i in range(3)]
def add(a, b): return [a[i] + b[i] for i in range(3)]
def transpose(m): return [[m[j][i] for j in range(3)] for i in range(3)]

world = []  # (R, t) per bone at bind pose
for name, parent, pos, rx in BONES:
    R = rotx(rx)
    if parent < 0:
        world.append((R, list(pos)))
    else:
        PR, Pt = world[parent]
        world.append((mmul(PR, R), add(mv(PR, pos), Pt)))

# ---------------------------------------------------------------- geometry
FACES = [((1, 0, 0), (0, 1, 0), (0, 0, 1)), ((-1, 0, 0), (0, 0, 1), (0, 1, 0)),
         ((0, 1, 0), (0, 0, 1), (1, 0, 0)), ((0, -1, 0), (1, 0, 0), (0, 0, 1)),
         ((0, 0, 1), (1, 0, 0), (0, 1, 0)), ((0, 0, -1), (0, 1, 0), (1, 0, 0))]

def box_geometry(bone, size, pos, rx_deg):
    WR, Wt = world[B[bone]]
    LR = rotx(math.radians(rx_deg))
    verts, norms, idx = [], [], []
    h = [s / 2 for s in size]
    for n, u, v in FACES:
        base = len(verts)
        nh = [n[i] * h[i] for i in range(3)]
        for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            p = [nh[i] + su * u[i] * h[i] + sv * v[i] * h[i] for i in range(3)]
            p = add(mv(LR, p), pos)           # box space -> bone space
            p = add(mv(WR, p), Wt)            # bone space -> bind (model) space
            verts.append(p)
            norms.append(mv(WR, mv(LR, list(n))))
        idx += [base, base + 1, base + 2, base, base + 2, base + 3]
    return verts, norms, idx

# ---------------------------------------------------------------- glTF assembly
buf = bytearray()
views, accessors = [], []

def pad4():
    while len(buf) % 4:
        buf.append(0)

def add_view(data, target=None):
    pad4()
    views.append({"buffer": 0, "byteOffset": len(buf), "byteLength": len(data), **({"target": target} if target else {})})
    buf.extend(data)
    return len(views) - 1

def add_acc(data, ctype, count, atype, target=None, minmax=None):
    acc = {"bufferView": add_view(data, target), "componentType": ctype, "count": count, "type": atype}
    if minmax:
        acc["min"], acc["max"] = minmax
    accessors.append(acc)
    return len(accessors) - 1

mat_names = list(MATS)
materials = []
for name in mat_names:
    m = MATS[name]
    d = {"name": name, "pbrMetallicRoughness": {"baseColorFactor": list(m["color"]) + [1.0],
         "metallicFactor": m.get("metal", 0.0), "roughnessFactor": m["rough"]}}
    if "emissive" in m:
        d["emissiveFactor"] = list(m["emissive"])
        d["extensions"] = {"KHR_materials_emissive_strength": {"emissiveStrength": m["strength"]}}
    materials.append(d)

meshes, mesh_order = [], ["Body", "Hair", "TankPlates"]
for mname in mesh_order:
    prims = []
    for mat in mat_names:
        V, N, I, J = [], [], [], []
        for (mesh, bone, bmat, size, pos, rx) in BOXES:
            if mesh != mname or bmat != mat:
                continue
            v, n, i = box_geometry(bone, size, pos, rx)
            off = len(V)
            V += v; N += n; I += [k + off for k in i]; J += [B[bone]] * len(v)
        if not V:
            continue
        pos_data = b"".join(struct.pack("<3f", *p) for p in V)
        mn = [min(p[k] for p in V) for k in range(3)]
        mx = [max(p[k] for p in V) for k in range(3)]
        a_pos = add_acc(pos_data, 5126, len(V), "VEC3", 34962, [mn, mx])
        a_nor = add_acc(b"".join(struct.pack("<3f", *p) for p in N), 5126, len(V), "VEC3", 34962)
        a_jnt = add_acc(b"".join(struct.pack("<4H", j, 0, 0, 0) for j in J), 5123, len(V), "VEC4", 34962)
        a_wgt = add_acc(b"".join(struct.pack("<4f", 1, 0, 0, 0) for _ in J), 5126, len(V), "VEC4", 34962)
        a_idx = add_acc(b"".join(struct.pack("<H", k) for k in I), 5123, len(I), "SCALAR", 34963)
        prims.append({"attributes": {"POSITION": a_pos, "NORMAL": a_nor, "JOINTS_0": a_jnt, "WEIGHTS_0": a_wgt},
                      "indices": a_idx, "material": mat_names.index(mat)})
    meshes.append({"name": mname, "primitives": prims})

# inverse bind matrices (column-major)
ibm = bytearray()
for R, t in world:
    Rt = transpose(R)
    it = [-x for x in mv(Rt, t)]
    cols = [[Rt[r][c] for r in range(3)] + [0.0] for c in range(3)] + [it + [1.0]]
    for col in cols:
        ibm += struct.pack("<4f", *col)
a_ibm = add_acc(bytes(ibm), 5126, len(BONES), "MAT4")

# nodes: joints 0..6, mesh nodes 7..9, scene root 10
nodes = []
for i, (name, parent, pos, rx) in enumerate(BONES):
    nodes.append({"name": name, "translation": list(pos), "rotation": [math.sin(rx / 2), 0, 0, math.cos(rx / 2)],
                  "children": [j for j, b in enumerate(BONES) if b[1] == i]})
for k, mname in enumerate(mesh_order):
    nodes.append({"name": mname, "mesh": k, "skin": 0})
nodes.append({"name": "Zombie", "children": [0, 7, 8, 9]})
for n in nodes:
    if n.get("children") == []:
        del n["children"]

# ---------------------------------------------------------------- animations
def qx(a): return [math.sin(a / 2), 0.0, 0.0, math.cos(a / 2)]
REST = {name: rx for name, _, _, rx in BONES}

def make_anim(name, duration, steps, fn):
    """fn(t) -> {bone: ('rot', angle_x) | ('pos', (x,y,z))}"""
    times = [duration * i / steps for i in range(steps + 1)]
    samples = [fn(t) for t in times]
    tracks = sorted({(b, kind) for s in samples for b, (kind, _) in s.items()})
    t_acc = add_acc(b"".join(struct.pack("<f", t) for t in times), 5126, len(times), "SCALAR", None, [[times[0]], [times[-1]]])
    samplers, channels = [], []
    for bone, kind in tracks:
        if kind == "rot":
            data = b"".join(struct.pack("<4f", *qx(s[bone][1])) for s in samples)
            acc = add_acc(data, 5126, len(times), "VEC4"); path = "rotation"
        else:
            data = b"".join(struct.pack("<3f", *s[bone][1]) for s in samples)
            acc = add_acc(data, 5126, len(times), "VEC3"); path = "translation"
        samplers.append({"input": t_acc, "output": acc, "interpolation": "LINEAR"})
        channels.append({"sampler": len(samplers) - 1, "target": {"node": B[bone], "path": path}})
    return {"name": name, "samplers": samplers, "channels": channels}

TAU = math.tau
def walk(t):
    p = t * TAU  # one full leg cycle per second
    drag = 0.55  # left leg is injured: shorter swing
    return {"LegL": ("rot", math.sin(p) * 0.7 * drag + 0.12), "LegR": ("rot", -math.sin(p) * 0.78),
            "ArmL": ("rot", REST["ArmL"] + 0.55 + math.sin(p + 0.4) * 0.12), "ArmR": ("rot", REST["ArmR"] + 0.35 - math.sin(p + 0.2) * 0.14),
            "Torso": ("rot", REST["Torso"] - 0.1 + math.sin(p * 2) * 0.04 + math.sin(p) * 0.03),
            "Head": ("rot", REST["Head"] + 0.18 + math.sin(p * 2 + 0.7) * 0.07 + math.sin(p) * 0.04),
            "Root": ("pos", (0, abs(math.sin(p)) * 0.03 - 0.03, 0))}
def idle(t):
    p = t / 2.0 * TAU
    return {"Torso": ("rot", REST["Torso"] - 0.08 + math.sin(p) * 0.03),
            "ArmL": ("rot", REST["ArmL"] + 0.3 + math.sin(p) * 0.06), "ArmR": ("rot", REST["ArmR"] + 0.15 + math.sin(p + 0.6) * 0.06),
            "Head": ("rot", REST["Head"] + 0.2 + math.sin(p + 1.0) * 0.06),
            "LegL": ("rot", 0.06)}
def attack(t):
    k = math.sin(min(t / 0.3, 1.0) * math.pi)       # 0 -> 1 -> 0
    return {"Root": ("pos", (0, 0, -0.25 * k)),
            "Torso": ("rot", REST["Torso"] - 0.25 * k),
            "ArmL": ("rot", REST["ArmL"] + 0.55 * k), "ArmR": ("rot", REST["ArmR"] + 0.55 * k)}
def death(t):
    k = min(t / 0.35, 1.0)
    e = 1 - (1 - k) ** 2
    return {"Root": ("rot", -math.pi / 2 * e),
            "ArmL": ("rot", REST["ArmL"] + 1.2 * e), "ArmR": ("rot", REST["ArmR"] + 1.2 * e)}

animations = [make_anim("walk", 1.0, 16, walk), make_anim("idle", 2.0, 8, idle),
              make_anim("attack", 0.3, 6, attack), make_anim("death", 0.35, 7, death)]

pad4()
gltf = {
    "asset": {"version": "2.0", "generator": "zombie-forest make_zombie_gltf.py"},
    "extensionsUsed": ["KHR_materials_emissive_strength"],
    "scene": 0, "scenes": [{"name": "Zombie", "nodes": [10]}],
    "nodes": nodes, "meshes": meshes, "materials": materials,
    "skins": [{"name": "ZombieSkin", "inverseBindMatrices": a_ibm, "joints": list(range(len(BONES))), "skeleton": 0}],
    "animations": animations, "accessors": accessors, "bufferViews": views,
    "buffers": [{"byteLength": len(buf), "uri": "data:application/octet-stream;base64," + base64.b64encode(bytes(buf)).decode()}],
}
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "models", "zombie.gltf")
with open(out, "w") as f:
    json.dump(gltf, f)
print("wrote", os.path.normpath(out), len(buf), "bytes of data,", sum(len(m["primitives"]) for m in meshes), "primitives")
