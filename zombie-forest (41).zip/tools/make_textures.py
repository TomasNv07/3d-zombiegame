#!/usr/bin/env python3
"""Generates the tileable forest textures into assets/textures/ (needs numpy + Pillow).

  ground.png  ground_n.png    forest floor: soil, moss, leaf litter, pine needles, twigs, pebbles
  dirt.png    dirt_n.png      bare dirt around the campfire
  bark.png    bark_n.png      deep vertical furrows, a bit of moss
  needles.png needles_n.png   dense layered pine needles
  stone.png   stone_n.png     cracked rock with lichen
  grass.png                   one grass clump with alpha (crossed quads in art.gd)

Colour textures are sRGB, *_n.png are normal maps (OpenGL / Godot convention).
Run:  python3 tools/make_textures.py   then   python3 tools/make_prefabs.py
Every texture tiles seamlessly (except grass.png).
"""
import math, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "assets", "textures")
os.makedirs(OUT, exist_ok=True)


def band_noise(size, seed, beta=2.0, f0=1.0, fc=64.0, aspect=1.0):
    """Seamless filtered noise in [-1, 1]. aspect > 1 stretches features along Y."""
    r = np.random.default_rng(seed)
    spec = np.fft.fft2(r.standard_normal((size, size)))
    k = np.fft.fftfreq(size) * size
    KX, KY = np.meshgrid(k, k)
    f = np.sqrt(KX ** 2 + (KY * aspect) ** 2)
    f[0, 0] = 1.0
    amp = f ** (-beta / 2.0) * np.exp(-(f / fc) ** 2) * (1.0 - np.exp(-(f / f0) ** 2))
    amp[0, 0] = 0.0
    n = np.real(np.fft.ifft2(spec * amp))
    n -= n.mean()
    return n / (np.abs(n).max() + 1e-9)


def to01(n):
    return np.clip(n * 0.5 + 0.5, 0.0, 1.0)


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def lerp(a, b, t):
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)
    return a + (b - a) * t[..., None]


def normal_map(height, strength=3.0):
    gx = (np.roll(height, -1, 1) - np.roll(height, 1, 1)) * 0.5
    gy = (np.roll(height, -1, 0) - np.roll(height, 1, 0)) * 0.5
    nx = -gx * strength * height.shape[0] / 128.0
    ny = gy * strength * height.shape[0] / 128.0
    nz = np.ones_like(nx)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    n = np.stack([nx / ln, ny / ln, nz / ln], -1)
    return ((n * 0.5 + 0.5) * 255).astype(np.uint8)


def save_rgb(arr, name):
    Image.fromarray((np.clip(arr, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB").save(os.path.join(OUT, name), optimize=True)
    print("wrote", name)


def save_normal(arr, name):
    Image.fromarray(arr, "RGB").save(os.path.join(OUT, name), optimize=True)
    print("wrote", name)


class Layer:
    """Supersampled RGBA colour + height layer whose shapes wrap at the edges (so it tiles)."""
    def __init__(self, size, ss=2):
        self.size, self.ss, self.S = size, ss, size * ss
        self.rgba = Image.new("RGBA", (self.S, self.S), (0, 0, 0, 0))
        self.hgt = Image.new("L", (self.S, self.S), 0)
        self.dc, self.dh = ImageDraw.Draw(self.rgba), ImageDraw.Draw(self.hgt)

    def _wrap(self, pts):
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        ox = [0] + ([self.S] if min(xs) < 0 else []) + ([-self.S] if max(xs) >= self.S else [])
        oy = [0] + ([self.S] if min(ys) < 0 else []) + ([-self.S] if max(ys) >= self.S else [])
        for a in ox:
            for b in oy:
                yield [(x + a, y + b) for x, y in pts]

    @staticmethod
    def _c(color):
        return tuple(int(np.clip(v, 0, 1) * 255) for v in color) + (255,)

    def poly(self, pts, color, h):
        pts = [(x * self.ss, y * self.ss) for x, y in pts]
        for p in self._wrap(pts):
            self.dc.polygon(p, fill=self._c(color))
            self.dh.polygon(p, fill=int(np.clip(h, 0, 1) * 255))

    def line(self, p0, p1, color, width, h):
        pts = [(p0[0] * self.ss, p0[1] * self.ss), (p1[0] * self.ss, p1[1] * self.ss)]
        w = max(1, int(round(width * self.ss)))
        for p in self._wrap(pts):
            self.dc.line(p, fill=self._c(color), width=w)
            self.dh.line(p, fill=int(np.clip(h, 0, 1) * 255), width=w)

    def ellipse(self, cx, cy, rx, ry, rot, color, h, n=12):
        cr, sr = math.cos(rot), math.sin(rot)
        pts = []
        for i in range(n):
            a = i * math.tau / n
            x, y = math.cos(a) * rx, math.sin(a) * ry
            pts.append((cx + x * cr - y * sr, cy + x * sr + y * cr))
        self.poly(pts, color, h)

    def result(self):
        """-> rgb (un-premultiplied), alpha, height, all float32 at final size"""
        s = self.size
        la = np.asarray(self.rgba.resize((s, s), Image.BOX), dtype=np.float32) / 255.0
        lh = np.asarray(self.hgt.resize((s, s), Image.BOX), dtype=np.float32) / 255.0
        a = la[..., 3]
        rgb = np.where(a[..., None] > 1e-3, la[..., :3] / np.maximum(a[..., None], 1e-3), 0.0)
        return np.clip(rgb, 0, 1), a, lh


def voronoi(size, count, seed):
    r = np.random.default_rng(seed)
    pts = r.random((count, 2)) * size
    ys, xs = np.mgrid[0:size, 0:size].astype(np.float32)
    best = np.full((size, size), 1e9, np.float32)
    second = np.full((size, size), 1e9, np.float32)
    ids = np.zeros((size, size), np.int32)
    for i, (px, py) in enumerate(pts):
        dx = np.abs(xs - px); dx = np.minimum(dx, size - dx)
        dy = np.abs(ys - py); dy = np.minimum(dy, size - dy)
        d = np.sqrt(dx * dx + dy * dy)
        closer = d < best
        second = np.where(closer, best, np.minimum(second, d))
        ids = np.where(closer, i, ids)
        best = np.where(closer, d, best)
    return best / size, second / size, ids


def tile_blur(a, radius):
    """gaussian blur that wraps around the edges"""
    s = a.shape[0]
    img = Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8))
    big = Image.new("L", (s * 3, s * 3))
    for ix in range(3):
        for iy in range(3):
            big.paste(img, (ix * s, iy * s))
    return np.asarray(big.filter(ImageFilter.GaussianBlur(radius)), dtype=np.float32)[s:2 * s, s:2 * s] / 255.0


# ----------------------------------------------------------------------------- forest floor
def make_ground(size=1024):
    r = np.random.default_rng(7)
    S = size
    base_noise = band_noise(size, 101, beta=2.6, f0=1.0, fc=10)
    mid_noise = band_noise(size, 102, beta=1.6, f0=6, fc=70)
    fine_noise = band_noise(size, 103, beta=1.0, f0=30, fc=250)
    moss_mask = smoothstep(0.45, 0.8, to01(band_noise(size, 104, beta=2.4, f0=1.5, fc=14)))

    soil = lerp([0.045, 0.036, 0.026], [0.13, 0.095, 0.06], to01(base_noise * 0.8 + mid_noise * 0.5))
    moss = lerp([0.05, 0.085, 0.035], [0.11, 0.17, 0.06], to01(mid_noise * 0.8 + fine_noise * 0.4))
    col = lerp(soil, moss, moss_mask * 0.8)
    col *= (0.88 + 0.24 * to01(fine_noise))[..., None]
    height = 0.45 + 0.2 * mid_noise + 0.08 * fine_noise + 0.12 * moss_mask

    L = Layer(size)
    leaf_cols = [(0.20, 0.12, 0.05), (0.16, 0.09, 0.04), (0.22, 0.16, 0.06), (0.13, 0.10, 0.05),
                 (0.17, 0.07, 0.04), (0.14, 0.13, 0.06)]
    for _ in range(520):                                    # dead leaves
        x, y = r.random() * S, r.random() * S
        ln = r.uniform(16, 38)
        c = np.array(leaf_cols[r.integers(len(leaf_cols))]) * r.uniform(0.6, 1.0)
        c = c * 0.8 + c.mean() * 0.2
        rot = r.random() * math.tau
        L.ellipse(x, y, ln, ln * r.uniform(0.35, 0.55), rot, c, r.uniform(0.62, 0.8))
        dx, dy = math.cos(rot) * ln, math.sin(rot) * ln
        L.line((x - dx, y - dy), (x + dx, y + dy), c * 0.6, 1, 0.9)
    for _ in range(3800):                                   # fallen needles
        x, y = r.random() * S, r.random() * S
        a = r.random() * math.tau
        ln = r.uniform(10, 22)
        c = np.array([0.20, 0.15, 0.08]) * r.uniform(0.6, 1.15)
        L.line((x, y), (x + math.cos(a) * ln, y + math.sin(a) * ln), c, 1, r.uniform(0.6, 0.75))
    for _ in range(70):                                     # twigs
        x, y = r.random() * S, r.random() * S
        a = r.random() * math.tau
        ln = r.uniform(60, 170)
        bend = r.uniform(-0.35, 0.35)
        mx, my = x + math.cos(a) * ln * 0.5, y + math.sin(a) * ln * 0.5
        ex, ey = mx + math.cos(a + bend) * ln * 0.5, my + math.sin(a + bend) * ln * 0.5
        c = np.array([0.075, 0.052, 0.034]) * r.uniform(0.8, 1.3)
        wd = r.uniform(2.0, 3.5)
        L.line((x, y), (mx, my), c, wd, 0.85)
        L.line((mx, my), (ex, ey), c, wd * 0.8, 0.85)
        if r.random() < 0.6:
            sa = a + r.choice([-1, 1]) * r.uniform(0.5, 0.9)
            L.line((mx, my), (mx + math.cos(sa) * ln * 0.25, my + math.sin(sa) * ln * 0.25), c * 0.9, 1.5, 0.8)
    for _ in range(45):                                     # pebbles
        x, y = r.random() * S, r.random() * S
        rad = r.uniform(4, 11)
        g = r.uniform(0.09, 0.2)
        c = np.array([g, g * 0.98, g * 1.05])
        L.ellipse(x, y, rad, rad * r.uniform(0.7, 1.0), r.random() * math.tau, c * 0.7, 0.8, 10)
        L.ellipse(x - rad * 0.12, y - rad * 0.15, rad * 0.78, rad * 0.62, 0, c, 0.95, 10)
    for _ in range(60):                                     # moss tufts
        x, y = r.random() * S, r.random() * S
        for _k in range(r.integers(4, 9)):
            L.ellipse(x + r.normal(0, 7), y + r.normal(0, 7), r.uniform(2, 5), r.uniform(2, 5), 0,
                      np.array([0.06, 0.12, 0.04]) * r.uniform(0.8, 1.5), 0.7, 8)

    rgb, alpha, lh = L.result()
    out = col * (1 - alpha[..., None]) + rgb * alpha[..., None]
    ao = 1.0 - 0.35 * np.clip(tile_blur(alpha, 5) - alpha, 0, 1)
    out *= ao[..., None]
    height = np.where(alpha > 0.05, lh, height * 0.6)
    save_rgb(out, "ground.png")
    save_normal(normal_map(np.clip(height, 0, 1), 3.2), "ground_n.png")


# ----------------------------------------------------------------------------- campfire dirt
def make_dirt(size=512):
    r = np.random.default_rng(11)
    n1 = band_noise(size, 201, beta=2.4, f0=1.5, fc=12)
    n2 = band_noise(size, 202, beta=1.4, f0=8, fc=90)
    n3 = band_noise(size, 203, beta=0.9, f0=40, fc=220)
    col = lerp([0.075, 0.05, 0.032], [0.20, 0.145, 0.095], to01(n1 * 0.7 + n2 * 0.6)) * (0.85 + 0.3 * to01(n3))[..., None]
    height = 0.5 + 0.2 * n2 + 0.1 * n3
    L = Layer(size)
    for _ in range(260):                                    # pebbles with a darker underside
        x, y = r.random() * size, r.random() * size
        rad = r.uniform(1.5, 6.5)
        g = r.uniform(0.12, 0.26)
        c = np.array([g, g * 0.9, g * 0.75])
        L.ellipse(x, y, rad, rad * 0.8, r.random() * math.tau, c * 0.6, 0.75, 9)
        L.ellipse(x - rad * 0.1, y - rad * 0.15, rad * 0.8, rad * 0.65, 0, c, 0.9, 9)
    rgb, a, ph = L.result()
    col = col * (1 - a[..., None]) + rgb * a[..., None]
    col *= (1.0 - 0.3 * np.clip(tile_blur(a, 2) - a, 0, 1))[..., None]
    height = np.where(a > 0.05, ph, height)
    save_rgb(col, "dirt.png")
    save_normal(normal_map(np.clip(height, 0, 1), 3.0), "dirt_n.png")


# ----------------------------------------------------------------------------- bark
def make_bark(size=512):
    n_coarse = band_noise(size, 301, beta=1.8, f0=5, fc=30, aspect=12.0)
    n_mid = band_noise(size, 302, beta=1.6, f0=10, fc=70, aspect=9.0)
    n_fine = band_noise(size, 303, beta=1.0, f0=30, fc=200, aspect=2.5)
    wob = band_noise(size, 306, beta=2.5, f0=2, fc=10, aspect=2.0)
    plate = smoothstep(0.015, 0.2, np.abs(n_coarse + 0.04 * wob))
    plate2 = smoothstep(0.01, 0.1, np.abs(n_mid))
    cracks = smoothstep(0.88, 1.0, 1.0 - np.abs(band_noise(size, 304, beta=1.5, f0=8, fc=60, aspect=0.3)))
    height = np.clip(0.1 + 0.62 * plate + 0.16 * plate2 * plate + 0.08 * n_fine - 0.3 * cracks * plate, 0, 1)

    furrow, mid, crest = np.array([0.025, 0.018, 0.014]), np.array([0.13, 0.092, 0.065]), np.array([0.24, 0.18, 0.13])
    t = np.clip(height, 0, 1)
    col = np.where((t < 0.5)[..., None], lerp(furrow, mid, t * 2.0), lerp(mid, crest, (t - 0.5) * 2.0))
    col *= (0.85 + 0.3 * to01(n_mid))[..., None]
    moss = smoothstep(0.62, 0.85, to01(band_noise(size, 305, beta=2.4, f0=2, fc=14))) * smoothstep(0.25, 0.6, height)
    col = lerp(col, np.array([0.07, 0.11, 0.04]) * (0.7 + 0.6 * to01(n_fine))[..., None], moss * 0.45)
    save_rgb(col, "bark.png")
    save_normal(normal_map(height, 5.5), "bark_n.png")


# ----------------------------------------------------------------------------- pine needles
def make_needles(size=512):
    r = np.random.default_rng(31)
    S = size
    under = to01(band_noise(size, 401, beta=2.0, f0=2, fc=30))
    shades = [(0.025, 0.07, 0.04), (0.04, 0.11, 0.055), (0.06, 0.16, 0.07), (0.09, 0.22, 0.09), (0.12, 0.28, 0.11)]
    L = Layer(size)
    for count, lo, hi in [(2600, 0.0, 0.25), (3000, 0.25, 0.6), (2600, 0.55, 1.0)]:
        for _ in range(count):
            x, y = r.random() * S, r.random() * S
            base_a = r.random() * math.tau
            fan = r.integers(2, 5)
            ln = r.uniform(18, 40)
            v = r.uniform(lo, hi)
            c = np.array(shades[min(int(v * len(shades)), len(shades) - 1)]) * r.uniform(0.85, 1.2)
            if r.random() < 0.05:
                c = np.array((0.17, 0.13, 0.05)) * r.uniform(0.7, 1.1)
            for k in range(fan):
                a = base_a + (k - (fan - 1) / 2) * 0.16 + r.normal(0, 0.03)
                ex, ey = x + math.cos(a) * ln, y + math.sin(a) * ln
                L.line((x + 1.5, y + 1.5), (ex + 1.5, ey + 1.5), c * 0.35, 1.4, 0.0)
                L.line((x, y), (ex, ey), c, 1.1, 0.25 + 0.7 * v)
    rgb, a, hgt = L.result()
    base = np.array([0.012, 0.03, 0.02], np.float32)
    col = (base * (1 - a[..., None]) + rgb * a[..., None]) * (0.85 + 0.3 * under)[..., None]
    save_rgb(col, "needles.png")
    hgt = np.asarray(Image.fromarray((hgt * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.8)), dtype=np.float32) / 255.0
    save_normal(normal_map(hgt, 3.5), "needles_n.png")


# ----------------------------------------------------------------------------- stone
def make_stone(size=512):
    f1, f2, ids = voronoi(size, 34, 501)
    cr = np.random.default_rng(502)
    cell_val = cr.random(34).astype(np.float32)
    cell_tint = cr.random(34).astype(np.float32)
    edge = f2 - f1
    cracks = (1.0 - smoothstep(0.0, 0.01, edge)) * smoothstep(0.35, 0.6, to01(band_noise(size, 506, beta=2.0, f0=2, fc=16)))
    n1 = band_noise(size, 503, beta=2.0, f0=3, fc=30)
    n2 = band_noise(size, 504, beta=1.1, f0=20, fc=200)
    val = cell_val[ids]
    height = np.clip(0.55 + 0.18 * (val - 0.5) + 0.2 * n1 + 0.1 * n2 - 0.4 * cracks, 0, 1)
    t = to01(n1 * 0.9 + (val - 0.5) * 0.6 + n2 * 0.2)
    col = lerp([0.07, 0.07, 0.085], [0.24, 0.24, 0.26], t)
    col = lerp(col, [0.22, 0.2, 0.18], cell_tint[ids] * 0.3)
    col *= (0.82 + 0.36 * to01(n2))[..., None]
    col *= (1.0 - 0.6 * cracks)[..., None]
    lichen = smoothstep(0.62, 0.8, to01(band_noise(size, 505, beta=1.6, f0=5, fc=40))) * smoothstep(0.35, 0.6, height)
    col = lerp(col, np.array([0.17, 0.22, 0.12]) * (0.7 + 0.6 * to01(n2))[..., None], lichen * 0.6)
    save_rgb(col, "stone.png")
    save_normal(normal_map(height, 4.0), "stone_n.png")


# ----------------------------------------------------------------------------- grass clump (RGBA)
def make_grass(size=256):
    r = np.random.default_rng(61)
    ss = 4
    S = size * ss
    img = Image.new("RGBA", (S, S), (90, 140, 60, 0))
    d = ImageDraw.Draw(img)
    blades = []
    for i in range(15):
        x0 = r.uniform(0.2, 0.8)
        h = r.uniform(0.45, 0.97) * (1.0 - 0.45 * abs(x0 - 0.5))
        blades.append((h, x0, r.normal(0, 0.12) + (x0 - 0.5) * 0.35, r.uniform(0.028, 0.05)))
    blades.sort()
    for h, x0, lean, w in blades:
        steps = 40
        left, right = [], []
        for k in range(steps + 1):
            t = k / steps
            cx, cy = x0 + lean * t * t, 1.0 - h * t
            wd = w * (1.0 - t) ** 0.7
            left.append((cx - wd, cy)); right.append((cx + wd, cy))
        tone = r.uniform(0.85, 1.1)
        for k in range(steps):
            t = (k + 0.5) / steps
            sh = (0.30 + 0.70 * t ** 0.9) * tone              # dark root -> lighter tip
            c = (0.50 * sh, 0.95 * sh, 0.40 * sh)               # neutral green; art.gd tints it
            quad = [left[k], left[k + 1], right[k + 1], right[k]]
            d.polygon([(px * S, py * S) for px, py in quad], fill=tuple(int(min(v, 1) * 255) for v in c) + (255,))
    img = img.resize((size, size), Image.BOX)
    a = np.asarray(img, dtype=np.float32) / 255.0
    rgb = np.where(a[..., 3:4] > 1e-3, a[..., :3] / np.maximum(a[..., 3:4], 1e-3), 0.35)
    out = np.concatenate([np.clip(rgb, 0, 1), a[..., 3:4]], -1)
    Image.fromarray((out * 255).astype(np.uint8), "RGBA").save(os.path.join(OUT, "grass.png"), optimize=True)
    print("wrote grass.png")


if __name__ == "__main__":
    make_ground(); make_dirt(); make_bark(); make_needles(); make_stone(); make_grass()
    print("done")
